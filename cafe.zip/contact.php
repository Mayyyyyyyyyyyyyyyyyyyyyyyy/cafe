<?php

session_start();

$conn = new mysqli("localhost", "root", "", "cafe_amore_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$result = $conn->query("SELECT image_path, paragraphs FROM about_content WHERE id = 1");
$content = $result->fetch_assoc();
$image = htmlspecialchars($content['image_path']);
$paragraphs = json_decode($content['paragraphs'], true);

$footer_result = $conn->query("SELECT * FROM footer_content WHERE id = 1");
$footer_content = $footer_result->fetch_assoc();

$conn->close();


function get_social_username($url) {
    return basename(parse_url($url, PHP_URL_PATH));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Café Amore | Contact</title>
  <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    .footer-section.social p {
      font-size: 0.9rem; 
      margin: 5px 0;   
    }
  </style>
</head>
<body>
  <header>
    <nav class="navbar">
      <div class="logo"><span><img src="coffee-logo.png" alt=""></span> Café Amore</div>
      <ul class="nav-links" id="navLinks">
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="menu.php">Menu</a></li>
        <li><a href="contact.php" class="active">Contact</a></li>
        <li><a href="notification.php" title="Notification"><i class="fas fa-bell"></i></a></li>
        <li><a href="setting.php" title="Settings"><i class="fas fa-cog"></i></a></li>
        <li><a href="login.php" title="Log Out"><i class="fas fa-sign-out-alt"></i></a></li>
      </ul>
      <div class="hamburger" id="hamburger">☰</div>
    </nav>
  </header>

  <section id="contact">
    <h2>Get In Touch</h2>
    <p class="contact-intro">We'd love to hear from you! Whether you have a question, feedback, or just want to say hello, feel free to reach out.</p>
    <div class="contact-wrapper">
      <div class="contact-details">
        <h3>Our Information</h3>
        <div class="info-item">
          <i class="fas fa-map-marker-alt"></i>
          <p><strong>Address:</strong><br>123 Coffee Lane, Brew City</p>
        </div>
        <div class="info-item">
          <i class="fas fa-phone"></i>
          <p><strong>Phone:</strong><br>(123) 456-7890</p>
        </div>
        <div class="info-item">
          <i class="fas fa-envelope"></i>
          <p><strong>Email:</strong><br>contact@cafeamore.com</p>
        </div>
        <div class="info-item">
          <i class="fas fa-clock"></i>
          <p><strong>Hours:</strong><br>Mon - Fri: 7am - 8pm<br>Sat - Sun: 8am - 9pm</p>
        </div>
      </div>
      <div class="contact-form-container">
        <h3>Send us a Message</h3>
        <form id="contactForm">
          <input type="text" id="name" placeholder="Your Name" required />
          <input type="email" id="email" placeholder="Your Email" required />
          <textarea id="message" rows="5" placeholder="Your Message" required></textarea>
          <button type="submit">Send Message</button>
        </form>
        <p id="formMessage"></p>
      </div>
    </div>
  </section>

  <footer>
    <div class="footer-content">
      <!-- About Section -->
      <div class="footer-section about">
        <h3>About Café Amore</h3>
        <p><?php echo htmlspecialchars($footer_content['about_text']); ?></p>
      </div>
      <!-- Contact Section -->
      <div class="footer-section contact-info">
        <h3>Contact Us</h3>
        <?php if (!empty($footer_content['address'])): ?><p><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($footer_content['address']); ?></p><?php endif; ?>
        <?php if (!empty($footer_content['phone'])): ?><p><i class="fas fa-phone"></i> <?php echo htmlspecialchars($footer_content['phone']); ?></p><?php endif; ?>
        <?php if (!empty($footer_content['email'])): ?><p><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($footer_content['email']); ?></p><?php endif; ?>
      </div>
      <!-- Social Section -->
      <div class="footer-section social">
        <h3>Follow Us</h3>
        <?php if (!empty($footer_content['facebook_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['facebook_url']); ?>" target="_blank"><i class="fab fa-facebook-f"></i> <?php echo get_social_username($footer_content['facebook_url']); ?></a></p><?php endif; ?>
        <?php if (!empty($footer_content['instagram_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['instagram_url']); ?>" target="_blank"><i class="fab fa-instagram"></i> <?php echo get_social_username($footer_content['instagram_url']); ?></a></p><?php endif; ?>
        <?php if (!empty($footer_content['twitter_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['twitter_url']); ?>" target="_blank"><i class="fab fa-twitter"></i> <?php echo get_social_username($footer_content['twitter_url']); ?></a></p><?php endif; ?>
      </div>
    </div>
    <div class="footer-bottom">
      <p>© 2025 Café Amore. All rights reserved.</p>
    </div>
  </footer>

  <script>
    const hamburger = document.getElementById("hamburger");
    const navLinks = document.getElementById("navLinks");
    hamburger.addEventListener("click", () => navLinks.classList.toggle("show"));
 
    const form = document.getElementById("contactForm");
    const formMessage = document.getElementById("formMessage");
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const name = document.getElementById("name").value.trim();
      const email = document.getElementById("email").value.trim();
      const message = document.getElementById("message").value.trim();
 
      if (!name || !email || !message) {
        formMessage.textContent = "Please fill out all fields!";
        formMessage.style.color = "red";
        return;
      } else if (!email.includes("@")) {
        formMessage.textContent = "Please enter a valid email!";
        formMessage.style.color = "red";
        return;
      }
 
      try {
        const response = await fetch('save_contact_message.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, email, message })
        });
        const result = await response.json();
 
        if (result.success) {
          formMessage.textContent = "Message sent successfully!";
          formMessage.style.color = "green";
          form.reset();
          setTimeout(() => { formMessage.textContent = ""; }, 3000);
        } else {
          formMessage.textContent = "Error: " + result.message;
          formMessage.style.color = "red";
        }
      } catch (error) {
        formMessage.textContent = "An unexpected error occurred. Please try again.";
        formMessage.style.color = "red";
      }
    });
  </script>
</body>
</html>
