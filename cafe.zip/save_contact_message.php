<?php
session_start();
header('Content-Type: application/json');

$response = ['success' => false, 'message' => 'Invalid request.'];

// Get the posted data
$data = json_decode(file_get_contents('php://input'), true);

$name = $data['name'] ?? null;
$email = $data['email'] ?? null;
$message = $data['message'] ?? null;

if ($name && $email && $message) {
    $conn = new mysqli("localhost", "root", "", "cafe_amore_db");
    if ($conn->connect_error) {
        $response['message'] = "Database connection failed.";
    } else {
        $stmt = $conn->prepare("INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $message);

        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = 'Message sent successfully!';

            
            $notif_message = "New message from " . htmlspecialchars($name);
            $admin_notif_stmt = $conn->prepare("INSERT INTO notifications (type, message) VALUES ('new_message', ?)");
            $admin_notif_stmt->bind_param("s", $notif_message);
            $admin_notif_stmt->execute();

    
            if (isset($_SESSION['user_id'])) {
                $user_id = $_SESSION['user_id'];
                $user_notif_message = "Your message has been sent successfully!";
                $user_notif_stmt = $conn->prepare("INSERT INTO notifications (user_id, type, message) VALUES (?, 'message_sent', ?)");
                $user_notif_stmt->bind_param("is", $user_id, $user_notif_message);
                $user_notif_stmt->execute();
            }
        } else {
            $response['message'] = 'Database error: ' . $stmt->error;
        }
        $stmt->close();
        $conn->close();
    }
}

echo json_encode($response);
?>