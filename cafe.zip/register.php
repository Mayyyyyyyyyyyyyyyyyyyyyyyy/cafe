<?php
session_start();
$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // --- DATABASE CONNECTION ---
    $servername = "localhost";
    $db_username = "root"; 
    $db_password = "";     
    $dbname = "cafe_amore_db"; 
     
    $conn = new mysqli($servername, $db_username, $db_password, $dbname);

    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // --- FORM DATA ---
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];

    // --- VALIDATION ---
    if ($password !== $confirmPassword) {
        $message = "Passwords do not match!";
    } else {
        
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $message = "Username or email already taken!";
        } else {
            // Ligtas na i-hash ang password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // I-insert ang bagong user
            $insert_stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            $insert_stmt->bind_param("sss", $username, $email, $hashed_password);

            if ($insert_stmt->execute()) {
            
                $_SESSION['register_success'] = "Registration successful! You can now log in.";
                header("Location: login.php");
                exit();
            } else {
                $message = "Error: " . $insert_stmt->error;
            }
            $insert_stmt->close();
        }
        $stmt->close();
    }
    $conn->close();
}

$footer_conn = new mysqli("localhost", "root", "", "cafe_amore_db");
$footer_content = [];
if (!$footer_conn->connect_error) {
    $footer_result = $footer_conn->query("SELECT * FROM footer_content WHERE id = 1");
    if ($footer_result && $footer_result->num_rows > 0) {
        $footer_content = $footer_result->fetch_assoc();
    }
    $footer_conn->close();
}

if (empty($footer_content)) {
    $footer_content = [
        'about_text' => 'Your favorite spot for cozy brews and sweet bites.',
        'address' => '123 Coffee Lane, Brew City',
        'phone' => '(123) 456-7890',
        'email' => 'contact@cafeamore.com',
        'facebook_url' => '', 'instagram_url' => '', 'twitter_url' => ''
    ];
}


function get_social_username($url) {
    if (empty($url)) return '';
    return basename(parse_url($url, PHP_URL_PATH));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Café Amore | Register</title>
  <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    
    .button-group {
      display: flex;
      justify-content: space-between;
      gap: 10px;
      margin-top: 20px;
    }
    .button-group button {
      flex: 1;
      padding: 12px;
    }
    #cancelBtn {
      background-color: #6c757d; 
    }
    #registerMessage {
      margin-top: 15px;
      font-weight: bold;
      color: red; 
    }
  </style>
</head>
<body>
  <header>
    <nav class="navbar">
      <div class="logo"><span><img src="coffee-logo.png" alt=""></span> Café Amore</div>
      <ul class="nav-links" id="navLinks"></ul>
      <div class="hamburger" id="hamburger">☰</div>
    </nav>
  </header>

  <main>
    <section id="login-section">
      <div class="login-container">
        <h2>Create Account</h2>
        <p>Please fill in the details to register.</p>
        <?php if (!empty($message)): ?>
          <p id="registerMessage"><?php echo $message; ?></p>
        <?php endif; ?>
        <form id="registerForm" method="POST" action="register.php">
          <div class="input-group">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" placeholder="Enter your username" required>
          </div>
          <div class="input-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" placeholder="Enter your email" required>
          </div>
          <div class="input-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" placeholder="Enter your password" required>
          </div>
          <div class="input-group">
            <label for="confirmPassword">Confirm Password</label>
            <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirm your password" required>
          </div>
          <div class="button-group">
            <button type="button" id="cancelBtn">Cancel</button>
            <button type="submit">Register</button>
          </div>
        </form>
      </div>
    </section>
  </main>

  <footer>
    <div class="footer-content">
      <!-- About Section -->
      <div class="footer-section about">
        <h3>About Café Amore</h3>
        <p><?php echo htmlspecialchars($footer_content['about_text']); ?></p>
      </div>
      <!-- Contact Section -->
      <div class="footer-section contact-info">
        <h3>Contact Us</h3>
        <?php if (!empty($footer_content['address'])): ?><p><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($footer_content['address']); ?></p><?php endif; ?>
        <?php if (!empty($footer_content['phone'])): ?><p><i class="fas fa-phone"></i> <?php echo htmlspecialchars($footer_content['phone']); ?></p><?php endif; ?>
        <?php if (!empty($footer_content['email'])): ?><p><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($footer_content['email']); ?></p><?php endif; ?>
      </div>
      <!-- Social Section -->
      <div class="footer-section social">
        <h3>Follow Us</h3>
        <?php if (!empty($footer_content['facebook_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['facebook_url']); ?>" target="_blank"><i class="fab fa-facebook-f"></i> <?php echo get_social_username($footer_content['facebook_url']); ?></a></p><?php endif; ?>
        <?php if (!empty($footer_content['instagram_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['instagram_url']); ?>" target="_blank"><i class="fab fa-instagram"></i> <?php echo get_social_username($footer_content['instagram_url']); ?></a></p><?php endif; ?>
        <?php if (!empty($footer_content['twitter_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['twitter_url']); ?>" target="_blank"><i class="fab fa-twitter"></i> <?php echo get_social_username($footer_content['twitter_url']); ?></a></p><?php endif; ?>
      </div>
    </div>
    <div class="footer-bottom">
      <p>© 2025 Café Amore. All rights reserved.</p>
    </div>
  </footer>

  <script>
    const hamburger = document.getElementById("hamburger");
    const navLinks = document.getElementById("navLinks");
    hamburger.addEventListener("click", () => navLinks.classList.toggle("show"));

    document.getElementById("cancelBtn").addEventListener("click", () => {
      window.location.href = 'login.php';
    });

  </script>
</body>
</html>