<?php
header('Content-Type: application/json');

$response = ['success' => false, 'message' => 'An unknown error occurred.'];

// --- DATABASE CONNECTION ---
$conn = new mysqli("localhost", "root", "", "cafe_amore_db");
if ($conn->connect_error) {
    $response['message'] = "Database connection failed: " . $conn->connect_error;
    echo json_encode($response);
    exit();
}


$result = $conn->query("SELECT image_path FROM about_content WHERE id = 1");
$currentContent = $result->fetch_assoc();
$currentImagePath = $currentContent['image_path'];

$updateImage = false;


if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
    $file = $_FILES['image'];
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/jpg'];

    if (in_array($file['type'], $allowedTypes)) {
        $newFileName = uniqid('about_img_') . '_' . basename($file['name']);
        $uploadPath = __DIR__ . '/' . $newFileName;

        if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
            
            if ($currentImagePath !== 'slide1.jpg' && file_exists(__DIR__ . '/' . $currentImagePath)) {
                unlink(__DIR__ . '/' . $currentImagePath);
            }
            $currentImagePath = $newFileName; 
            $updateImage = true;
        }
    }
}


$paragraphsJSON = $_POST['paragraphs'] ?? '[]';


$stmt = $conn->prepare("UPDATE about_content SET image_path = ?, paragraphs = ? WHERE id = 1");
$stmt->bind_param("ss", $currentImagePath, $paragraphsJSON);

if ($stmt->execute()) {
    $response['success'] = true;
    $response['message'] = 'Content updated successfully!';
    if ($updateImage) {
        $response['newImagePath'] = $currentImagePath;
    }
} else {
    $response['message'] = 'Failed to update database: ' . $stmt->error;
}

$stmt->close();
$conn->close();

echo json_encode($response);
?>

