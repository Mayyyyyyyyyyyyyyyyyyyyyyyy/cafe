<?php
header('Content-Type: application/json');
session_start();

$response = ['success' => false, 'message' => 'An error occurred.'];


if (!isset($_SESSION['admin'])) {
    $response['message'] = 'Unauthorized access.';
    echo json_encode($response);
    exit;
}

$conn = new mysqli("localhost", "root", "", "cafe_amore_db");
if ($conn->connect_error) {
    $response['message'] = "Database connection failed.";
    echo json_encode($response);
    exit();
}

$aboutText = $_POST['aboutText'] ?? '';
$addressText = $_POST['addressText'] ?? '';
$phoneText = $_POST['phoneText'] ?? '';
$emailText = $_POST['emailText'] ?? '';
$facebookLink = $_POST['facebookLink'] ?? '';
$instagramLink = $_POST['instagramLink'] ?? '';
$twitterLink = $_POST['twitterLink'] ?? '';

$stmt = $conn->prepare("UPDATE footer_content SET about_text=?, address=?, phone=?, email=?, facebook_url=?, instagram_url=?, twitter_url=? WHERE id=1");
$stmt->bind_param("sssssss", $aboutText, $addressText, $phoneText, $emailText, $facebookLink, $instagramLink, $twitterLink);

if ($stmt->execute()) {
    $response['success'] = true;
    $response['message'] = 'Footer content updated successfully!';
} else {
    $response['message'] = 'Failed to update footer content in the database.';
}

$stmt->close();
$conn->close();
echo json_encode($response);
?>