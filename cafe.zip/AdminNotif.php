<?php

session_start();


$conn = new mysqli("localhost", "root", "", "cafe_amore_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$result = $conn->query("SELECT image_path, paragraphs FROM about_content WHERE id = 1");
$content = $result->fetch_assoc();
$image = htmlspecialchars($content['image_path']);
$paragraphs = json_decode($content['paragraphs'], true);

$footer_result = $conn->query("SELECT * FROM footer_content WHERE id = 1");
$footer_content = $footer_result->fetch_assoc();

$notif_result = $conn->query("SELECT * FROM notifications ORDER BY created_at DESC");
$notifications = [];
if ($notif_result) {
    while($row = $notif_result->fetch_assoc()) {
        $notifications[] = $row;
    }
  
    $conn->query("UPDATE notifications SET is_read = 1 WHERE is_read = 0");
}
$conn->close();


function get_social_username($url) {
    return basename(parse_url($url, PHP_URL_PATH));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Café Amore | Admin Activity & Notifications</title>
  <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    #notifications-section {
      padding: 100px 20px 60px;
      max-width: 1000px;
      margin: 0 auto;
      text-align: center;
    }
    #notifications-section h2 {
      font-size: 2.5rem;
      color: var(--accent-dark);
      margin-bottom: 40px;
    }
    .notifications-container {
      text-align: left;
    }
    .notification-item {
      background: #fff;
      border-radius: 10px;
      padding: 20px;
      margin-bottom: 15px;
      display: flex;
      align-items: center;
      gap: 20px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.08);
      border-left: 5px solid var(--accent);
    }
    .notification-item.type-new_order { border-left-color: #28a745; } 
    .notification-item.type-new_message { border-left-color: #007bff; } /* Blue */
    .notification-item.type-menu_update,
    .notification-item.type-menu_add,
    .notification-item.type-menu_delete { border-left-color: #ffc107; } /* Yellow */
    .notification-item.type-about_update { border-left-color: #17a2b8; } /* Teal */
    .notification-item.type-user_login { border-left-color: #6f42c1; } /* Indigo */

    .notification-icon {
      font-size: 1.8rem;
      width: 40px;
      text-align: center;
    }
    .notification-icon.icon-new_order { color: #28a745; }
    .notification-icon.icon-new_message { color: #007bff; }
    .notification-icon.icon-menu_update,
    .notification-icon.icon-menu_add,
    .notification-icon.icon-menu_delete { color: #ffc107; }
    .notification-icon.icon-about_update { color: #17a2b8; }
    .notification-icon.icon-user_login { color: #6f42c1; }

    .notification-content { flex-grow: 1; }
    .notification-content p {
      margin: 0;
      font-size: 1.1rem;
      color: var(--text);
    }
    .notification-content .timestamp {
      font-size: 0.85rem;
      color: #888;
      margin-top: 5px;
    }
    #no-notifications {
      font-size: 1.2rem;
      color: #888;
      padding: 40px;
    }
    .delete-notification-btn {
      background: none;
      border: none;
      color: #aaa;
      font-size: 1.2rem;
      cursor: pointer;
      transition: color 0.2s;
      margin-left: auto;
    }
    .delete-notification-btn:hover {
      color: #dc3545;
    }
  </style>
</head>
<body>
  <header>
    <nav class="navbar">
      <div class="logo"><span><img src="coffee-logo.png" alt=""></span> Café Amore</div>
      <ul class="nav-links" id="navLinks">
        <li><a href="AdminDashboard.php">Home</a></li>
        <li><a href="AdminAbout.php">About</a></li>
        <li><a href="AdminMenu.php">Menu</a></li>
        <li><a href="AdminContact.php">Contact</a></li>
        <li><a href="AdminNotif.php" class="active" title="Activity Log" style="position: relative;">
          <i class="fas fa-bell"></i><span class="notification-badge" id="admin-notif-badge"></span>
        </a></li>
        
        <li><a href="login.php" title="Log Out"><i class="fas fa-sign-out-alt"></i></a></li>
      </ul>
      <div class="hamburger" id="hamburger">☰</div>
    </nav>
  </header>

  <main>
    <section id="notifications-section">
      <h2>Activity & Notification Log</h2>
      <div class="notifications-container" id="notificationsContainer">
        <?php if (!empty($notifications)): ?>
          <?php foreach ($notifications as $notif):
              $iconClass = 'fas fa-bell'; // Default icon
              if ($notif['type'] === 'new_order') $iconClass = 'fas fa-receipt';
              if ($notif['type'] === 'new_message') $iconClass = 'fas fa-envelope';
              if ($notif['type'] === 'new_menu_item') $iconClass = 'fas fa-plus-square';
          ?>
            <div class="notification-item type-<?php echo $notif['type']; ?>">
              <div class="notification-icon icon-<?php echo $notif['type']; ?>"><i class="<?php echo $iconClass; ?>"></i></div>
              <div class="notification-content">
                <p><?php echo htmlspecialchars($notif['message']); ?></p>
                <div class="timestamp"><?php echo date('F j, Y, g:i a', strtotime($notif['created_at'])); ?></div>
              </div>
              <button class="delete-notification-btn" data-id="<?php echo $notif['id']; ?>" title="Delete Notification"><i class="fas fa-trash-alt"></i></button>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <p id="no-notifications">No new activity or notifications.</p>
        <?php endif; ?>
      </div>
    </section>
  </main>

  <footer>
    <div class="footer-content">
      <!-- About Section -->
      <div class="footer-section about">
        <h3>About Café Amore</h3>
        <p><?php echo htmlspecialchars($footer_content['about_text']); ?></p>
      </div>
      <!-- Contact Section -->
      <div class="footer-section contact-info">
        <h3>Contact Us</h3>
        <?php if (!empty($footer_content['address'])): ?><p><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($footer_content['address']); ?></p><?php endif; ?>
        <?php if (!empty($footer_content['phone'])): ?><p><i class="fas fa-phone"></i> <?php echo htmlspecialchars($footer_content['phone']); ?></p><?php endif; ?>
        <?php if (!empty($footer_content['email'])): ?><p><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($footer_content['email']); ?></p><?php endif; ?>
      </div>
      <!-- Social Section -->
      <div class="footer-section social">
        <h3>Follow Us</h3>
        <?php if (!empty($footer_content['facebook_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['facebook_url']); ?>" target="_blank"><i class="fab fa-facebook-f"></i> <?php echo get_social_username($footer_content['facebook_url']); ?></a></p><?php endif; ?>
        <?php if (!empty($footer_content['instagram_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['instagram_url']); ?>" target="_blank"><i class="fab fa-instagram"></i> <?php echo get_social_username($footer_content['instagram_url']); ?></a></p><?php endif; ?>
        <?php if (!empty($footer_content['twitter_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['twitter_url']); ?>" target="_blank"><i class="fab fa-twitter"></i> <?php echo get_social_username($footer_content['twitter_url']); ?></a></p><?php endif; ?>
      </div>
    </div>
    <div class="footer-bottom">
      <p>© 2025 Café Amore. All rights reserved.</p>
    </div>
  </footer>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
        const hamburger = document.getElementById("hamburger");
        const navLinks = document.getElementById("navLinks");
        hamburger.addEventListener("click", () => navLinks.classList.toggle("show"));
        const notificationsContainer = document.getElementById('notificationsContainer');

        notificationsContainer.addEventListener('click', function(e) {
            const deleteButton = e.target.closest('.delete-notification-btn');
            if (deleteButton) {
                const notifId = deleteButton.dataset.id;

                if (confirm('Are you sure you want to delete this notification? This action cannot be undone.')) {
                    
                    fetch('delete_notification.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ id: notifId })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            deleteButton.closest('.notification-item').remove();
                        } else {
                            alert('Error: ' + data.message);
                        }
                    });
                }
            }
        });
    });
  </script>
</body>
</html>