<?php
$conn = new mysqli("localhost", "root", "", "cafe_amore_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$menuResult = $conn->query("SELECT name, price, image FROM menu_items ORDER BY id ASC");
$menuItems = [];
if ($menuResult->num_rows > 0) {
    while ($row = $menuResult->fetch_assoc()) {
        $menuItems[] = $row;
    }
}

$footer_content = [];
$footerResult = $conn->query("SELECT * FROM footer_content LIMIT 1");
if ($footerResult && $footerResult->num_rows > 0) {
    $footer_content = $footerResult->fetch_assoc();
} else {
    
    $footer_content = [
        'about_text' => 'Welcome to Café Amore, where every cup is brewed with love.',
        'address' => '123 Coffee Lane, Brewtown',
        'phone' => '+1 (555) 123-4567',
        'email' => 'contact@cafeamore.com',
        'facebook_url' => '',
        'instagram_url' => '',
        'twitter_url' => ''
    ];
}

/**
 * Extracts a social media username from a URL.
 * @param string $url 
 * @return string 
 */
function get_social_username($url) {
    if (empty($url)) return '';
    $path = parse_url($url, PHP_URL_PATH);
    return basename($path);
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Café Amore | Menu</title>
  <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    
    #paymentForm label {
      display: flex;
      align-items: center;
      gap: 10px; 
      cursor: pointer;
      margin-bottom: 10px;
    }

    #paymentForm .fa-money-bill-wave { color: #28a745; } 
    #paymentForm .fa-wallet { color: #007bff; } 
    #paymentForm .fa-credit-card { color: #17a2b8; } 
  </style>
</head>
<body>
  <header>
    <nav class="navbar">
      <div class="logo"><span><img src="coffee-logo.png" alt=""></span> Café Amore</div>
      <ul class="nav-links" id="navLinks">
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="menu.php" class="active">Menu</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="notification.php" title="Notification"><i class="fas fa-bell"></i></a></li>
        <li><a href="setting.php" title="Settings"><i class="fas fa-cog"></i></a></li>
        <li><a href="login.php" title="Log Out"><i class="fas fa-sign-out-alt"></i></a></li>
      </ul>
      <div class="hamburger" id="hamburger">☰</div>
    </nav>
  </header>

  <section id="menu">
    <h2>Our Menu</h2>
    <p class="menu-subtitle">Click on any item to place an order.</p>
    <div class="menu-scroll-container">
      <div class="menu-items">
        <?php foreach ($menuItems as $item): ?>
          <div class="item" data-item="<?php echo htmlspecialchars($item['name']); ?>" data-price="₱<?php echo number_format($item['price'], 2); ?>">
            <img src="<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" />
            <div class="item-details">
              <h3><?php echo htmlspecialchars($item['name']); ?></h3>
              <p>₱<?php echo number_format($item['price'], 2); ?></p>
            </div>
          </div>
        <?php endforeach; ?>
        <?php if (empty($menuItems)): ?>
          <p>Our menu is currently being updated. Please check back soon!</p>
        <?php endif; ?>
      </div>
      <div class="scroll-arrows">
        <button class="scroll-arrow" id="scrollUp"><i class="fas fa-chevron-up"></i></button>
        <button class="scroll-arrow" id="scrollDown"><i class="fas fa-chevron-down"></i></button>
      </div>
    </div>
  </section>

  <!-- payment design -->
  <div class="paymentBox" id="paymentDisplay">
    <div class="paymentContent">
      <span class="closeButton" id="closeBtn">&times;</span>
      <h3 id="ItemName">Item Name</h3>
      <p id="itemPrice">₱0</p>
      <h4>Select Payment Method</h4>
      <form id="paymentForm">
        <label>
          <input type="radio" name="payment" value="Cash on Delivery" required />
          <i class="fas fa-money-bill-wave"></i> Cash on Delivery
        </label>
       <label>
  <input type="radio" name="payment" value="Gcash" />
  <img src="gcash-logo.png" alt="GCash" class="gcash-logo" style="width:25px; height:auto;">
  GCash
</label>

        <label>
          <input type="radio" name="payment" value="Credit Card" />
          <i class="fas fa-credit-card"></i> Credit Card
        </label>
        <button type="submit">Confirm Payment</button>
      </form>
      <p id="paymentMessage"></p>
    </div>
  </div>

  <!-- credentials design -->
  <div class="paymentBox" id="credentialsDisplay">
    <div class="paymentContent">
      <span class="closeButton" id="closeCredentialsBox">&times;</span>
      <h3 id="paymentTitle">Payment Details</h3>
      <form id="credentialsForm">
        <div id="Fields"></div>
        <button type="submit">Confirm Details</button>
      </form>
      <p id="credentialsMessage"></p>
    </div>
  </div>

 <footer>
  <div class="footer-content">
    <!-- About Section -->
    <div class="footer-section about">
      <h3>About Café Amore</h3>
      <p><?php echo htmlspecialchars($footer_content['about_text']); ?></p>
    </div>

    <!-- Contact Section -->
    <div class="footer-section contact-info">
      <h3>Contact Us</h3>
      <?php if (!empty($footer_content['address'])): ?>
        <p><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($footer_content['address']); ?></p>
      <?php endif; ?>
      <?php if (!empty($footer_content['phone'])): ?>
        <p><i class="fas fa-phone"></i> <?php echo htmlspecialchars($footer_content['phone']); ?></p>
      <?php endif; ?>
      <?php if (!empty($footer_content['email'])): ?>
        <p><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($footer_content['email']); ?></p>
      <?php endif; ?>
    </div>

    <!-- Social Section -->
    <div class="footer-section social">
      <h3>Follow Us</h3>
      <?php if (!empty($footer_content['facebook_url'])): ?>
        <p><a href="<?php echo htmlspecialchars($footer_content['facebook_url']); ?>" target="_blank"><i class="fab fa-facebook-f"></i> <?php echo get_social_username($footer_content['facebook_url']); ?></a></p>
      <?php endif; ?>
      <?php if (!empty($footer_content['instagram_url'])): ?>
        <p><a href="<?php echo htmlspecialchars($footer_content['instagram_url']); ?>" target="_blank"><i class="fab fa-instagram"></i> <?php echo get_social_username($footer_content['instagram_url']); ?></a></p>
      <?php endif; ?>
      <?php if (!empty($footer_content['twitter_url'])): ?>
        <p><a href="<?php echo htmlspecialchars($footer_content['twitter_url']); ?>" target="_blank"><i class="fab fa-twitter"></i> <?php echo get_social_username($footer_content['twitter_url']); ?></a></p>
      <?php endif; ?>
    </div>
  </div>

  <div class="footer-bottom">
    <p>© 2025 Café Amore. All rights reserved.</p>
  </div>
</footer>

  <!-- Back to Top Arrow -->
  <button class="back-to-top" id="backToTopBtn"><i class="fas fa-arrow-up"></i></button>

  <script>
    const hamburger = document.getElementById("hamburger");
    const navLinks = document.getElementById("navLinks");
    hamburger.addEventListener("click", () => navLinks.classList.toggle("show"));

    const items = document.querySelectorAll(".item");
    const paymentDisplay = document.getElementById("paymentDisplay");
    const closeBtn = document.getElementById("closeBtn");
    const itemName = document.getElementById("ItemName");
    const itemPrice = document.getElementById("itemPrice");
    const paymentForm = document.getElementById("paymentForm");
    const paymentMessage = document.getElementById("paymentMessage");

    const credentialsDisplay = document.getElementById("credentialsDisplay");
    const closeCredentialsBox = document.getElementById("closeCredentialsBox");
    const Fields = document.getElementById("Fields");
    const paymentTitle = document.getElementById("paymentTitle");
    const credentialsForm = document.getElementById("credentialsForm");
    const credentialsMessage = document.getElementById("credentialsMessage");

    let currentPrice = 0;

  
    async function saveOrderToServer(item, price, paymentMethod) {
      try {
        const response = await fetch('save-order.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            item: item,
            price: price,
            paymentMethod: paymentMethod
          })
        });
        const result = await response.json();
        console.log('Server response:', result.message); // For debugging
      } catch (error) {
        console.error('Error saving order to server:', error);
      }
    }

    items.forEach(item => {
      item.addEventListener("click", () => {
        const name = item.getAttribute("data-item");
        const priceText = item.getAttribute("data-price");
        currentPrice = parseFloat(priceText.replace(/[₱,]/g, ""));
        itemName.textContent = name;
        itemPrice.textContent = priceText;
        paymentDisplay.style.display = "flex";
        paymentMessage.textContent = "";
        paymentForm.reset();
      });
    });

    closeBtn.addEventListener("click", () => (paymentDisplay.style.display = "none"));
    closeCredentialsBox.addEventListener("click", () => (credentialsDisplay.style.display = "none"));

    paymentForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const selectedPayment = paymentForm.payment.value;

      if (selectedPayment === "Cash on Delivery") {
        paymentMessage.style.color = "green";
        paymentMessage.textContent = `Payment confirmed using ${selectedPayment}. Thank you!`;

        // Save to server
        saveOrderToServer(itemName.textContent, itemPrice.textContent, selectedPayment);

        setTimeout(() => {
          paymentDisplay.style.display = "none";
        }, 1800);
      } else {
        paymentDisplay.style.display = "none";
        credentialsDisplay.style.display = "flex";
        credentialsMessage.textContent = "";
        credentialsForm.reset();

        if (selectedPayment === "Gcash") {
          paymentTitle.textContent = "GCash Payment Details";
          Fields.innerHTML = `
            <label>GCash Number:</label>
            <input type="text" id="gcashNumber" placeholder="+63" required />
            <label>Enter Amount:</label>
            <input type="number" id="gcashAmount" placeholder="Enter amount to pay" required />
          `;
        } else if (selectedPayment === "Credit Card") {
          paymentTitle.textContent = "Credit Card Payment Details";
          Fields.innerHTML = `
            <label>Card Number:</label>
            <input type="text" id="cardNumber" placeholder="0000-0000-0000-0000" required />
            <label>Expiry Date:</label>
            <input type="Date" id="expiryDate" required />
            <label>CVV:</label>
            <input type="text" id="cvv" maxlength="3" placeholder="123" required />
          `;
        }

        credentialsForm.onsubmit = (event) => {
          event.preventDefault();

          if (selectedPayment === "Gcash") {
            const enteredAmount = parseFloat(document.getElementById("gcashAmount").value);
            const remaining = enteredAmount - currentPrice;

            if (isNaN(enteredAmount) || enteredAmount < currentPrice) {
              credentialsMessage.style.color = "red";
              credentialsMessage.textContent = "Insufficient amount. Please enter a valid amount.";
              return;
            }

            credentialsMessage.style.color = "green";
            credentialsMessage.textContent = `Payment successful! Here's your change: ₱${remaining.toFixed(2)}`;

          } else {
            credentialsMessage.style.color = "green";
            credentialsMessage.textContent = "Credit Card payment successful! Thank you for your purchase.";
          }

      
          if (credentialsMessage.style.color === "green") {
          
            saveOrderToServer(itemName.textContent, itemPrice.textContent, selectedPayment);
          }

          setTimeout(() => {
            credentialsDisplay.style.display = "none";
          }, 1800);
        };
      }
    });

    window.addEventListener("click", (e) => {
      if (e.target === paymentDisplay) paymentDisplay.style.display = "none";
      if (e.target === credentialsDisplay) credentialsDisplay.style.display = "none";
    });

    const menuItems = document.querySelector(".menu-items");
    const scrollUpBtn = document.getElementById("scrollUp");
    const scrollDownBtn = document.getElementById("scrollDown");

    function updateArrowVisibility() {
      const isScrollable = menuItems.scrollHeight > menuItems.clientHeight;
      const scrollArrowsContainer = document.querySelector('.scroll-arrows');

      if (isScrollable) {
        scrollArrowsContainer.style.display = 'flex';
      
        scrollUpBtn.style.visibility = menuItems.scrollTop > 0 ? 'visible' : 'hidden';
        
        const atBottom = menuItems.scrollTop + menuItems.clientHeight >= menuItems.scrollHeight - 1;
        scrollDownBtn.style.visibility = atBottom ? 'hidden' : 'visible';
      } else {
        scrollArrowsContainer.style.display = 'none';
      }
    }

    
    updateArrowVisibility();

    
    menuItems.addEventListener("scroll", updateArrowVisibility);

    scrollUpBtn.addEventListener("click", () => {
      menuItems.scrollBy({ top: -200, behavior: 'smooth' });
    });
    scrollDownBtn.addEventListener("click", () => {
      menuItems.scrollBy({ top: 200, behavior: 'smooth' });
    });

    const backToTopBtn = document.getElementById("backToTopBtn");
    window.addEventListener("scroll", () => {
      if (window.scrollY > 200) {
        backToTopBtn.classList.add("show");
      } else {
        backToTopBtn.classList.remove("show");
      }
    });
    backToTopBtn.addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  </script>
</body>
</html>
