<?php

session_start();


$conn = new mysqli("localhost", "root", "", "cafe_amore_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$result = $conn->query("SELECT image_path, paragraphs FROM about_content WHERE id = 1");
$content = $result->fetch_assoc();
$image = htmlspecialchars($content['image_path']);
$paragraphs = json_decode($content['paragraphs'], true);


$footer_result = $conn->query("SELECT * FROM footer_content WHERE id = 1");
$footer_content = $footer_result->fetch_assoc();

$conn->close();


function get_social_username($url) {
    return basename(parse_url($url, PHP_URL_PATH));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Café Amore | Menu</title>
  <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>

    .edit-modal {
      display: none; 
      position: fixed;
      z-index: 1001;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0,0,0,0.6);
      justify-content: center;
      align-items: center;
    }

    .edit-modal-content {
      background-color: #fefefe;
      margin: auto;
      padding: 30px;
      border: 1px solid #888;
      width: 90%;
      max-width: 500px;
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.3);
      position: relative;
    }

    .edit-modal-content h2 {
      margin-top: 0;
      color: var(--accent-dark);
    }

    .form-group {
      margin-bottom: 15px;
      text-align: left;
    }

    .form-group label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
    }

    .form-group input[type="text"],
    .form-group input[type="number"],
    .form-group input[type="file"] {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    #itemImagePreview {
      max-width: 120px;
      max-height: 120px;
      border-radius: 8px;
      margin-top: 10px;
      display: none; 
      object-fit: cover;
    }

    .modal-buttons {
      display: flex;
      justify-content: space-between;
      margin-top: 25px;
    }

    .modal-buttons button {
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      color: white;
      font-size: 1rem;
    }

    #saveItemBtn { background-color: #28a745; }
    #deleteItemBtn { background-color: #dc3545; }
    #closeModalBtn { background-color: #6c757d; }

    .menu-header {
      display: flex;
      justify-content: center; 
      align-items: center;
      position: relative;
      margin-bottom: 30px;
    }

    #addNewItemBtn {
      position: absolute;
      right: 0; 
      background-color: var(--accent);
      color: white;
      border: none;
      padding: 12px 25px;
      font-size: 1.1rem;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.3s;
    }
    #addNewItemBtn:hover {
      background-color: var(--accent-dark);
    }
    .footer-section.social p {
      font-size: 0.9rem; 
      margin: 5px 0;   
    }
  </style>
</head>
<body>
  <header>
    <nav class="navbar">
      <div class="logo"><span><img src="coffee-logo.png" alt=""></span> Café Amore</div>
      <ul class="nav-links" id="navLinks">
        <li><a href="AdminDashboard.php">Home</a></li>
        <li><a href="AdminAbout.php">About</a></li>
        <li><a href="AdminMenu.php" class="active">Menu</a></li>
        <li><a href="AdminContact.php">Contact</a></li>
        <li><a href="AdminNotif.php" title="Activity Log"><i class="fas fa-bell"></i></a></li>
        <li><a href="login.php" title="Log Out"><i class="fas fa-sign-out-alt"></i></a></li>
      </ul>
      <div class="hamburger" id="hamburger">☰</div>
    </nav>
  </header>

  <section id="menu">
    <div class="menu-header">
      <h2>Manage Menu</h2>
      <button id="addNewItemBtn"><i class="fas fa-plus"></i> Add New Item</button>
    </div>
    <div class="menu-scroll-container">
      <div class="menu-items">
      
      </div>
      <div class="scroll-arrows">
        <button class="scroll-arrow" id="scrollUp"><i class="fas fa-chevron-up"></i></button>
        <button class="scroll-arrow" id="scrollDown"><i class="fas fa-chevron-down"></i></button>
      </div>
    </div>
  </section>

  
  <div id="editItemModal" class="edit-modal">
    <div class="edit-modal-content">
      <h2 id="modalTitle">Edit Menu Item</h2>
      <form id="editItemForm">
        <input type="hidden" id="editItemId">
        <div class="form-group">
          <label for="itemNameInput">Item Name</label>
          <input type="text" id="itemNameInput" required>
        </div>
        <div class="form-group">
          <label for="itemPriceInput">Price (e.g., 120)</label>
          <input type="number" id="itemPriceInput" required>
        </div>
        <div class="form-group">
          <label for="itemImageInput">Upload Image</label>
          <input type="file" id="itemImageInput" accept="image/*">
          <img id="itemImagePreview" src="#" alt="Image Preview">
        </div>
        <div class="modal-buttons">
          <button type="button" id="deleteItemBtn">Delete</button>
          <div>
            <button type="button" id="closeModalBtn">Cancel</button>
            <button type="submit" id="saveItemBtn">Save Changes</button>
          </div>
        </div>
      </form>
    </div>
  </div>

  <footer>
    <div class="footer-content">
      
      <div class="footer-section about">
        <h3>About Café Amore</h3>
        <p><?php echo htmlspecialchars($footer_content['about_text']); ?></p>
      </div>
    
      <div class="footer-section contact-info">
        <h3>Contact Us</h3>
        <?php if (!empty($footer_content['address'])): ?><p><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($footer_content['address']); ?></p><?php endif; ?>
        <?php if (!empty($footer_content['phone'])): ?><p><i class="fas fa-phone"></i> <?php echo htmlspecialchars($footer_content['phone']); ?></p><?php endif; ?>
        <?php if (!empty($footer_content['email'])): ?><p><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($footer_content['email']); ?></p><?php endif; ?>
      </div>
      
      <div class="footer-section social">
        <h3>Follow Us</h3>
        <?php if (!empty($footer_content['facebook_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['facebook_url']); ?>" target="_blank"><i class="fab fa-facebook-f"></i> <?php echo get_social_username($footer_content['facebook_url']); ?></a></p><?php endif; ?>
        <?php if (!empty($footer_content['instagram_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['instagram_url']); ?>" target="_blank"><i class="fab fa-instagram"></i> <?php echo get_social_username($footer_content['instagram_url']); ?></a></p><?php endif; ?>
        <?php if (!empty($footer_content['twitter_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['twitter_url']); ?>" target="_blank"><i class="fab fa-twitter"></i> <?php echo get_social_username($footer_content['twitter_url']); ?></a></p><?php endif; ?>
      </div>
    </div>
    <div class="footer-bottom">
      <p>© 2025 Café Amore. All rights reserved.</p>
    </div>
  </footer>

  <button class="back-to-top" id="backToTopBtn"><i class="fas fa-arrow-up"></i></button>

  <script>
    const hamburger = document.getElementById("hamburger");
    const navLinks = document.getElementById("navLinks");
    hamburger.addEventListener("click", () => navLinks.classList.toggle("show"));

    const menuItemsContainer = document.querySelector(".menu-items");
    const editModal = document.getElementById('editItemModal');
    const closeModalBtn = document.getElementById('closeModalBtn');
    const editForm = document.getElementById('editItemForm');
    const addNewItemBtn = document.getElementById('addNewItemBtn');
    const deleteItemBtn = document.getElementById('deleteItemBtn');
    const modalTitle = document.getElementById('modalTitle');
    const itemImagePreview = document.getElementById('itemImagePreview');

    let menuItems = [];

    async function fetchMenuItems() {
        try {
            const response = await fetch('get_menu_items.php');
            menuItems = await response.json();
            renderMenuItems();
        } catch (error) {
            console.error('Failed to fetch menu items:', error);
        }
    }

    function renderMenuItems() {
        menuItemsContainer.innerHTML = '';
        menuItems.forEach(item => {
            const itemDiv = document.createElement('div');
            itemDiv.className = 'item';
            itemDiv.setAttribute('data-id', item.id);
            itemDiv.innerHTML = `
                <img src="${item.image}" alt="${item.name}" />
                <div class="item-details">
                    <h3>${item.name}</h3>
                    <p>₱${parseFloat(item.price).toFixed(2)}</p>
                </div>
            `;
            itemDiv.addEventListener('click', () => openEditModal(item));
            menuItemsContainer.appendChild(itemDiv);
        });
        updateArrowVisibility();
    }

    function openEditModal(item) {
      modalTitle.textContent = 'Edit Menu Item';
      document.getElementById('editItemId').value = item.id;
      document.getElementById('itemNameInput').value = item.name;
      document.getElementById('itemPriceInput').value = item.price;
      document.getElementById('itemImageInput').value = ''; 
      itemImagePreview.src = item.image;
      itemImagePreview.style.display = 'block';
      deleteItemBtn.style.display = 'block';
      editModal.style.display = 'flex';
    }

    function openAddModal() {
      modalTitle.textContent = 'Add New Item';
      editForm.reset();
      document.getElementById('editItemId').value = '';
      itemImagePreview.style.display = 'none';
      deleteItemBtn.style.display = 'none'; 
      editModal.style.display = 'flex';
    }

    function closeModal() {
      editModal.style.display = 'none';
    }

    addNewItemBtn.addEventListener('click', openAddModal);
    closeModalBtn.addEventListener('click', closeModal);
    window.addEventListener('click', (e) => e.target === editModal && closeModal());

    document.getElementById('itemImageInput').addEventListener('change', function(event) {
      const file = event.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
          itemImagePreview.src = e.target.result;
          itemImagePreview.style.display = 'block';
        }
        reader.readAsDataURL(file);
      }
    });

    editForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const formData = new FormData();
      const itemId = document.getElementById('editItemId').value;
      const itemName = document.getElementById('itemNameInput').value;

      formData.append('action', 'save');
      formData.append('id', itemId);
      formData.append('name', itemName);
      formData.append('price', document.getElementById('itemPriceInput').value);
      
      const imageFile = document.getElementById('itemImageInput').files[0];
      if (imageFile) {
        formData.append('image', imageFile);
      }

      try {
        const response = await fetch('manage_menu_item.php', {
          method: 'POST',
          body: formData
        });
        const result = await response.json();
        alert(result.message);
        if (result.success) {
        
          const isNewItem = !itemId;
          const adminNotifType = isNewItem ? 'menu_add' : 'menu_update';
          const adminNotifMessage = isNewItem 
            ? `New menu item "${itemName}" was added.`
            : `Menu item "${itemName}" was updated.`;
          
          const adminNotifications = JSON.parse(localStorage.getItem('adminNotifications')) || [];          
          adminNotifications.unshift({ type: adminNotifType, message: adminNotifMessage, timestamp: new Date().toISOString() });
          localStorage.setItem('adminNotifications', JSON.stringify(adminNotifications.slice(0, 50)));

          if (isNewItem) {
            const userNotifications = JSON.parse(localStorage.getItem('userNotifications')) || [];
            userNotifications.unshift({
              type: 'new_menu',
              message: `Check out our new item: <strong>${itemName}</strong>!`,
              timestamp: new Date().toISOString()
            });
            localStorage.setItem('userNotifications', JSON.stringify(userNotifications.slice(0, 50)));
          }
          
          fetchMenuItems(); 
          closeModal();
        }
      } catch (error) {
        console.error('Save failed:', error);
        alert('An error occurred while saving.');
      }
    });

    deleteItemBtn.addEventListener('click', async () => {
      const id = document.getElementById('editItemId').value;
      const itemName = document.getElementById('itemNameInput').value;
      if (confirm('Are you sure you want to delete this item?')) {
        const formData = new FormData();
        formData.append('action', 'delete');
        formData.append('id', id);

        const response = await fetch('manage_menu_item.php', { method: 'POST', body: formData });
        const result = await response.json();
        alert(result.message);
        if (result.success) {
          
          const adminNotifications = JSON.parse(localStorage.getItem('adminNotifications')) || [];
          adminNotifications.unshift({
              type: 'menu_delete',
              message: `Menu item "${itemName}" was deleted.`,
              timestamp: new Date().toLocaleString()
          });
          localStorage.setItem('adminNotifications', JSON.stringify(adminNotifications.slice(0, 50)));
          

          fetchMenuItems();
          closeModal();
        }
      }
    });

    
    const scrollUpBtn = document.getElementById("scrollUp");
    const scrollDownBtn = document.getElementById("scrollDown");

    function updateArrowVisibility() {
      const isScrollable = menuItemsContainer.scrollHeight > menuItemsContainer.clientHeight;
      const scrollArrowsContainer = document.querySelector('.scroll-arrows');

      if (isScrollable) {
        scrollArrowsContainer.style.display = 'flex';
        scrollUpBtn.style.visibility = menuItemsContainer.scrollTop > 0 ? 'visible' : 'hidden';
        const atBottom = menuItemsContainer.scrollTop + menuItemsContainer.clientHeight >= menuItemsContainer.scrollHeight - 1;
        scrollDownBtn.style.visibility = atBottom ? 'hidden' : 'visible';
      } else {
        scrollArrowsContainer.style.display = 'none';
      }
    }

    scrollUpBtn.addEventListener("click", () => {
      menuItemsContainer.scrollBy({ top: -200, behavior: 'smooth' });
    });
    scrollDownBtn.addEventListener("click", () => {
      menuItemsContainer.scrollBy({ top: 200, behavior: 'smooth' });
    });
    menuItemsContainer.addEventListener("scroll", updateArrowVisibility);

    
    const backToTopBtn = document.getElementById("backToTopBtn");
    window.addEventListener("scroll", () => {
      if (window.scrollY > 200) {
        backToTopBtn.classList.add("show");
      } else {
        backToTopBtn.classList.remove("show");
      }
    });
    backToTopBtn.addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    
    fetchMenuItems();
  </script>
</body>
</html>
