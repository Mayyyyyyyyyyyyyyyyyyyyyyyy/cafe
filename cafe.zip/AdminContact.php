<?php

session_start();

$conn = new mysqli("localhost", "root", "", "cafe_amore_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$result = $conn->query("SELECT image_path, paragraphs FROM about_content WHERE id = 1");
$content = $result->fetch_assoc();
$image = htmlspecialchars($content['image_path']);
$paragraphs = json_decode($content['paragraphs'], true);

$footer_result = $conn->query("SELECT * FROM footer_content WHERE id = 1");
$footer_content = $footer_result->fetch_assoc();

$messages_result = $conn->query("SELECT * FROM contact_messages ORDER BY sent_at DESC");
$contact_messages = [];
if ($messages_result) {
    while ($row = $messages_result->fetch_assoc()) {
        $contact_messages[] = $row;
    }
}

$conn->close();


function get_social_username($url) {
    return basename(parse_url($url, PHP_URL_PATH));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Café Amore | Contact Messages</title>
  <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    #messages-section {
      padding: 60px 20px;
      text-align: center;
    }
    #messages-section h2 {
      font-size: 2.5rem;
      margin-bottom: 40px;
    }
    .messages-container {
      max-width: 1200px;
      margin: 0 auto;
      overflow-x: auto;
    }
    .messages-table {
      width: 100%;
      border-collapse: collapse;
      box-shadow: 0 8px 20px rgba(0,0,0,0.07);
    }
    .messages-table th, .messages-table td {
      padding: 15px;
      border: 1px solid #ddd;
      text-align: left;
    }
    .messages-table thead {
      background-color: var(--accent-dark);
      color: white;
    }
    .messages-table tbody tr:nth-child(even) {
      background-color: #f9f9f9;
    }
    .messages-table tbody tr:hover {
      background-color: #f1f1f1;
    }
    #no-messages {
      font-size: 1.2rem;
      color: #888;
    }
    .action-buttons {
      display: flex;
      gap: 10px;
      align-items: center;
    }
    .action-btn {
      padding: 8px 12px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      color: white;
      text-decoration: none; 
      font-size: 0.9rem;
      transition: opacity 0.2s;
    }
    .action-btn:hover { opacity: 0.8; }
    .reply-btn { background-color: #28a745; }
    .delete-btn { background-color: #dc3545; }
    .post-btn { background-color: #007bff; } 
    .footer-section.social p {
      font-size: 0.9rem; 
      margin: 5px 0;   
    }

  </style>
</head>
<body>
  <header>
    <nav class="navbar">
      <div class="logo"><span><img src="coffee-logo.png" alt=""></span> Café Amore</div>
      <ul class="nav-links" id="navLinks">
        <li><a href="AdminDashboard.php">Home</a></li>
        <li><a href="AdminAbout.php">About</a></li>
        <li><a href="AdminMenu.php">Menu</a></li>
        <li><a href="AdminContact.php" class="active">Contact</a></li>
        <li><a href="AdminNotif.php" title="Notifications"><i class="fas fa-bell"></i></a></li>
        
        <li><a href="login.php" title="Log Out"><i class="fas fa-sign-out-alt"></i></a></li>
      </ul>
      <div class="hamburger" id="hamburger">☰</div>
    </nav>
  </header>

  <main>
    <section id="messages-section">
      <h2>Contact Form Messages</h2>
      <div class="messages-container">
        <table class="messages-table" id="messagesTable">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Message</th>
              <th>Date Sent</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!empty($contact_messages)): ?>
              <?php foreach ($contact_messages as $msg): ?>
                <tr data-id="<?php echo $msg['id']; ?>" data-name="<?php echo htmlspecialchars($msg['name']); ?>" data-message="<?php echo htmlspecialchars($msg['message']); ?>">
                  <td><?php echo htmlspecialchars($msg['name']); ?></td>
                  <td><?php echo htmlspecialchars($msg['email']); ?></td>
                  <td><?php echo htmlspecialchars($msg['message']); ?></td>
                  <td><?php echo date('F j, Y, g:i a', strtotime($msg['sent_at'])); ?></td>
                  <td class="action-buttons">
                    <button class="action-btn post-btn" title="Post this message to the homepage feedback section">Post</button>
                    <button class="action-btn delete-btn" title="Delete this message permanently">Delete</button>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
        <p id="no-messages" style="display: none;">No messages received yet.</p>
      </div>
    </section>
  </main>

  <footer>
    <div class="footer-content">
      
      <div class="footer-section about">
        <h3>About Café Amore</h3>
        <p><?php echo htmlspecialchars($footer_content['about_text']); ?></p>
      </div>
      
      <div class="footer-section contact-info">
        <h3>Contact Us</h3>
        <?php if (!empty($footer_content['address'])): ?><p><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($footer_content['address']); ?></p><?php endif; ?>
        <?php if (!empty($footer_content['phone'])): ?><p><i class="fas fa-phone"></i> <?php echo htmlspecialchars($footer_content['phone']); ?></p><?php endif; ?>
        <?php if (!empty($footer_content['email'])): ?><p><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($footer_content['email']); ?></p><?php endif; ?>
      </div>
      
      <div class="footer-section social">
        <h3>Follow Us</h3>
        <?php if (!empty($footer_content['facebook_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['facebook_url']); ?>" target="_blank"><i class="fab fa-facebook-f"></i> <?php echo get_social_username($footer_content['facebook_url']); ?></a></p><?php endif; ?>
        <?php if (!empty($footer_content['instagram_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['instagram_url']); ?>" target="_blank"><i class="fab fa-instagram"></i> <?php echo get_social_username($footer_content['instagram_url']); ?></a></p><?php endif; ?>
        <?php if (!empty($footer_content['twitter_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['twitter_url']); ?>" target="_blank"><i class="fab fa-twitter"></i> <?php echo get_social_username($footer_content['twitter_url']); ?></a></p><?php endif; ?>
      </div>
    </div>
    <div class="footer-bottom">
      <p>© 2025 Café Amore. All rights reserved.</p>
    </div>
  </footer>

  <script>
    const hamburger = document.getElementById("hamburger");
    const navLinks = document.getElementById("navLinks");
    hamburger.addEventListener("click", () => navLinks.classList.toggle("show"));

    const tableBody = document.querySelector("#messagesTable tbody");
    const noMessagesEl = document.getElementById('no-messages');
    const messagesTable = document.getElementById('messagesTable');

    
    if (tableBody.rows.length === 0) {
        noMessagesEl.style.display = 'block';
        messagesTable.style.display = 'none';
    }

    tableBody.addEventListener('click', function(e) {
      const row = e.target.closest('tr');
      if (!row) return;

      if (e.target.classList.contains('post-btn')) { 
        const quote = row.dataset.message;
        const authorName = row.dataset.name;
        const author = `- ${authorName}`;

        fetch('post_feedback.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ quote: quote, author: author }),
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            alert(`Message from ${authorName} has been posted to the homepage feedback section.`);
          
            e.target.disabled = true;
            e.target.textContent = 'Posted';
            e.target.style.backgroundColor = '#28a745'; 
          } else {
            alert('Error posting feedback: ' + data.message);
          }
        })
        .catch(error => console.error('Error:', error));
      } else if (e.target.classList.contains('delete-btn')) {
        if (confirm('Are you sure you want to permanently delete this message?')) {
          const messageId = row.dataset.id;

          fetch('delete_contact_message.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: messageId })
          })
          .then(response => response.json())
          .then(data => {
            if (data.success) {
              alert(data.message);
              row.remove(); 
              if (tableBody.rows.length === 0) {
                  noMessagesEl.style.display = 'block';
                  messagesTable.style.display = 'none';
              }
            } else {
              alert('Error: ' + data.message);
            }
          }).catch(error => console.error('Error:', error));
        }
      }
    });
  </script>
</body>
</html>