<?php
session_start();
$message = "";
$success_message = "";

if (isset($_SESSION['register_success'])) {
    $success_message = $_SESSION['register_success'];
    unset($_SESSION['register_success']);
}
// Kapag may form submit

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $username = $_POST['username'];
    $password = $_POST['password'];

    // --- Hardcoded Admin Login ---
    if ($username === 'Admin' && $password === 'Admin123') {
        $_SESSION['user_id'] = 0; // Special ID for hardcoded admin
        $_SESSION['username'] = 'Admin';
        $_SESSION['user_role'] = 'admin';
        $_SESSION['login_success_notification'] = true;
        header("Location: AdminDashboard.php");
        exit();
    }

    // --- Database User Login ---
    $conn = new mysqli("localhost", "root", "", "cafe_amore_db");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // --- User & Admin Login from DB ---
    $stmt = $conn->prepare("SELECT id, password, role FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        // Verify password (assuming you are using password_hash)
        if (password_verify($password, $user['password'])) {
            // Password is correct, set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $username;
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['login_success_notification'] = true;

            // Redirect based on role
            if ($user['role'] === 'admin') {
                header("Location: AdminDashboard.php");
            } else {
                header("Location: index.php");
            }
            exit();
        } else {
            // Incorrect password
            $message = "Invalid username or password.";
        }
    } else {
        // User not found
        $message = "Invalid username or password.";
    }

    $stmt->close();
    $conn->close();
}

$footer_conn = new mysqli("localhost", "root", "", "cafe_amore_db");
$footer_content = [];
if (!$footer_conn->connect_error) {
    $footer_result = $footer_conn->query("SELECT * FROM footer_content WHERE id = 1");
    if ($footer_result && $footer_result->num_rows > 0) {
        $footer_content = $footer_result->fetch_assoc();
    }
    $footer_conn->close();
}


if (empty($footer_content)) {
    $footer_content = [
        'about_text' => 'Your favorite spot for cozy brews and sweet bites.',
        'address' => '123 Coffee Lane, Brew City',
        'phone' => '(123) 456-7890',
        'email' => 'contact@cafeamore.com',
        'facebook_url' => '', 'instagram_url' => '', 'twitter_url' => ''
    ];
}


function get_social_username($url) {
    if (empty($url)) return '';
    return basename(parse_url($url, PHP_URL_PATH));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Café Amore | Login</title>
  <link rel="stylesheet" href="style.css" />
  <!-- Font Awesome for icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    .button-group {
      display: flex;
      justify-content: space-between;
      gap: 10px;
      margin-top: 20px;
    }
    .button-group button {
      flex: 1;
    }
    #registerBtn {
      background-color: #6c757d; /* Gray color */
    }

    .social-login-divider {
      display: flex;
      align-items: center;
      text-align: center;
      color: #888;
      margin: 25px 0;
    }
    .social-login-divider::before,
    .social-login-divider::after {
      content: '';
      flex: 1;
      border-bottom: 1px solid #ddd;
    }
    .social-login-divider span {
      padding: 0 10px;
    }
    .social-login-buttons {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .social-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 12px;
      border-radius: 8px;
      text-decoration: none;
      color: white;
      font-weight: bold;
      transition: opacity 0.2s;
    }
    .social-btn:hover { opacity: 0.9; }
    .social-btn.google { background-color: #DB4437; }
    .social-btn.facebook { background-color: #4267B2; }
    .social-btn i { margin-right: 10px; font-size: 1.2rem; }
  </style>
  <style>
    body {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        background-color: #fdfaf6;
        font-family: 'Poppins', sans-serif;
        padding: 20px;
    }
    .login-container {
        background: #fff;
        padding: 40px;
        border-radius: 10px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        width: 100%;
        max-width: 400px;
        text-align: center;
    }
    .login-container h1 {
        color: var(--accent-dark);
        margin-bottom: 10px;
        font-size: 1.8rem;
    }
    .login-container .logo-img {
        width: 50px;
        margin-bottom: 20px;
    }
    .login-container input {
        width: 100%;
        padding: 12px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-sizing: border-box;
    }
    .login-container .button-group button {
        font-size: 1rem;
        padding: 12px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    .login-container .button-group button[type="submit"] {
        background-color: var(--accent);
        color: white;
    }
    .form-message.success { color: #28a745; margin-bottom: 15px; background-color: #e9f7ef; padding: 10px; border-radius: 5px; }
    .error { color: #dc3545; margin-bottom: 15px; }
  </style>
</head>
<body>
  <div class="login-container">
    <img src="coffee-logo.png" alt="Café Amore Logo" class="logo-img">
    <h1>Login to Café Amore</h1>

    <?php if (!empty($success_message)): ?>
      <p class="form-message success"><?php echo htmlspecialchars($success_message); ?></p>
    <?php endif; ?>

    <?php if (!empty($message)): ?>
      <p class="error"><?php echo htmlspecialchars($message); ?></p>
    <?php endif; ?>

    <form action="login.php" method="POST">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <div class="button-group">
          <button type="submit">Login</button>
          <button type="button" id="registerBtn">Register</button>
        </div>
    </form>

    <div class="social-login-divider">
      <span>Or continue with</span>
    </div>

    <div class="social-login-buttons">
      <a href="#" class="social-btn google">
        <i class="fab fa-google"></i> Login with Google
      </a>
      <a href="#" class="social-btn facebook">
        <i class="fab fa-facebook-f"></i> Login with Facebook
      </a>
    </div>
  </div>

  <script>
    document.getElementById("registerBtn").addEventListener("click", () => {
      window.location.href = 'register.php';
    });
  </script>
</body>
</html>
