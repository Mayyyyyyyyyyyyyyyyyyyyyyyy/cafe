<?php
session_start();

// I-check kung naka-login ang user. Kung hindi, i-redirect sa login page.
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // O kung saan man ang login page mo
    exit;
}

// --- DATABASE CONNECTION ---
$conn = new mysqli("localhost", "root", "", "cafe_amore_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// --- FETCH USER DATA ---
$userId = $_SESSION['user_id'];
$query = "SELECT username, email, profile_picture FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
if ($stmt === false) {
    die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
}
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

// --- FETCH NOTIFICATION COUNT FOR ADMINS (if applicable) ---
$notif_count = 0;
if (isset($_SESSION['admin'])) {
    $count_result = $conn->query("SELECT COUNT(*) as unread_count FROM notifications WHERE is_read = 0");
    if ($count_result) {
        $notif_count = $count_result->fetch_assoc()['unread_count'];
    }
}


$message = '';
$message_type = '';

// I-handle ang form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];

    // Simpleng validation
    if (empty($username)) {
        $message = "Username cannot be empty.";
        $message_type = 'error';
    } elseif (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Please enter a valid email address.";
        $message_type = 'error';
    } elseif (!empty($newPassword) && $newPassword !== $confirmPassword) {
        $message = "Passwords do not match!";
        $message_type = 'error';
    } else {
        // Check if username or email already exists for another user
        $checkStmt = $conn->prepare("SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?");
        if ($checkStmt === false) {
            die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
        }
        $checkStmt->bind_param("ssi", $username, $email, $userId);
        $checkStmt->execute();
        $checkStmt->store_result();

        if ($checkStmt->num_rows > 0) {
            $message = "Username or email is already taken by another user.";
            $message_type = 'error';
        } else {

        $conn->begin_transaction();
        try {
            // Handle profile picture upload
            $profilePicPath = $user['profile_picture']; // Keep old one if no new one is uploaded
            if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == UPLOAD_ERR_OK) {
                $uploadDir = 'uploads/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0755, true);
                }
                $fileName = uniqid() . '-' . basename($_FILES['profile_picture']['name']);
                $targetPath = $uploadDir . $fileName;

                if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $targetPath)) {
                    // Delete old picture if it's not the default one
                    if ($profilePicPath && $profilePicPath !== 'default-avatar.png' && file_exists($profilePicPath)) {
                        unlink($profilePicPath);
                    }
                    $profilePicPath = $targetPath;
                }
            }

            // Update username, email, and profile picture
            $updateQuery = "UPDATE users SET username = ?, email = ?, profile_picture = ? WHERE id = ?";
            $stmt = $conn->prepare($updateQuery);
            if ($stmt === false) {
                die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
            }
            $stmt->bind_param("sssi", $username, $email, $profilePicPath, $userId);
            $stmt->execute();
            $stmt->close();

            // Update password kung may nilagay
            if (!empty($newPassword)) {
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                $_SESSION['username'] = $username; // Update session username
                $passQuery = "UPDATE users SET password = ? WHERE id = ?";
                $stmt = $conn->prepare($passQuery);
                if ($stmt === false) {
                    die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
                }
                $stmt->bind_param("si", $hashedPassword, $userId);
                $stmt->execute();
                $stmt->close();
            }

            $conn->commit();
            $message = "Profile updated successfully!";
            $message_type = 'success';

            // I-refresh ang user data para maipakita ang pagbabago
            $user['email'] = $email;
            $user['username'] = $username;
            $user['profile_picture'] = $profilePicPath;

        } catch (mysqli_sql_exception $exception) {
            $conn->rollback();
            $message = "An error occurred. Please try again.";
            $message_type = 'error';
        }}
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Settings</title>
    <link rel="stylesheet" href="style.css">
    <!-- Siguraduhing naka-link ang Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .profile-picture-container {
            text-align: center;
            margin-bottom: 20px;
        }
        .profile-picture {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #ddd;
            cursor: pointer;
        }
        #profile_picture_upload {
            display: none;
        }
        .upload-label {
            cursor: pointer;
            color: var(--accent);
        }
    </style>
</head>
<body>

    <header>
        <nav class="navbar">
            <div class="logo"><span><img src="coffee-logo.png" alt=""></span> Café Amore</div>
            <ul class="nav-links" id="navLinks">
                <li><a href="<?php echo isset($_SESSION['admin']) ? 'AdminDashboard.php' : 'index.php'; ?>" class="<?php echo (isset($_SESSION['admin']) && basename($_SERVER['PHP_SELF']) == 'AdminDashboard.php') || (!isset($_SESSION['admin']) && basename($_SERVER['PHP_SELF']) == 'index.php') ? 'active' : ''; ?>">Home</a></li>
                <li><a href="<?php echo isset($_SESSION['admin']) ? 'AdminAbout.php' : 'about.php'; ?>">About</a></li>
                <li><a href="<?php echo isset($_SESSION['admin']) ? 'AdminMenu.php' : 'menu.php'; ?>">Menu</a></li>
                <li><a href="<?php echo isset($_SESSION['admin']) ? 'AdminContact.php' : 'contact.php'; ?>">Contact</a></li>
                <li><a href="<?php echo isset($_SESSION['admin']) ? 'AdminNotif.php' : 'notification.php'; ?>" title="Notification" style="position: relative;">
                    <i class="fas fa-bell"></i>
                    <?php if (isset($_SESSION['admin']) && $notif_count > 0): ?>
                        <span class="notification-badge"><?php echo $notif_count > 9 ? '9+' : $notif_count; ?></span>
                    <?php elseif (!isset($_SESSION['admin'])): ?>
                        <span class="notification-badge" id="user-notif-badge"></span>
                    <?php endif; ?>
                </a></li>
                <li><a href="setting.php" class="active" title="Settings"><i class="fas fa-cog"></i></a></li>
                <li><a href="login.php" title="Log Out"><i class="fas fa-sign-out-alt"></i></a></li>
            </ul>
            <div class="hamburger" id="hamburger">☰</div>
        </nav>
    </header>

    <main id="login-section">
        <div class="login-container">
            <h2>Profile Settings</h2>
            <p>Update your profile information below.</p>

            <?php if (!empty($message)): ?>
                <div class="form-message <?php echo $message_type; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <form action="setting.php" method="POST" enctype="multipart/form-data">
                <div class="profile-picture-container">
                    <label for="profile_picture_upload">
                        <img src="<?php echo htmlspecialchars($user['profile_picture'] ?? 'default-avatar.png'); ?>" alt="Profile Picture" class="profile-picture" id="profile_picture_preview">
                    </label>
                    <input type="file" name="profile_picture" id="profile_picture_upload" accept="image/*">
                    <p><label for="profile_picture_upload" class="upload-label">Click image to change</label></p>
                </div>

                <div class="input-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                </div>

                <div class="input-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                </div>

                <div class="input-group">
                    <label for="new_password">New Password</label>
                    <input type="password" id="new_password" name="new_password" placeholder="Leave blank to keep current password">
                </div>

                <div class="input-group">
                    <label for="confirm_password">Confirm New Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm your new password">
                </div>

                <button type="submit">Update Profile</button>
            </form>
        </div>
    </main>

    <script>
        document.getElementById('profile_picture_upload').addEventListener('change', function(event) {
            const [file] = event.target.files;
            if (file) {
                const preview = document.getElementById('profile_picture_preview');
                preview.src = URL.createObjectURL(file);
                preview.onload = () => {
                    URL.revokeObjectURL(preview.src); // free memory
                }
            }
        });

        // Hamburger menu functionality
        const hamburger = document.getElementById("hamburger");
        const navLinks = document.getElementById("navLinks");
        if (hamburger && navLinks) {
            hamburger.addEventListener("click", () => navLinks.classList.toggle("show"));
        }

        // User Notification counter (client-side for non-admins)
        <?php if (!isset($_SESSION['admin'])): ?>
        function updateUserNotifCounter() {
            const lastCount = parseInt(localStorage.getItem('lastUserNotifCount') || 0);
            const contactMessages = JSON.parse(localStorage.getItem('contactMessages')) || [];
            const orderHistory = JSON.parse(localStorage.getItem('orderHistory')) || [];
            const userNotifications = JSON.parse(localStorage.getItem('userNotifications')) || [];
            const currentCount = contactMessages.length + orderHistory.length + userNotifications.length;
            const newNotifs = currentCount - lastCount;

            const badge = document.getElementById('user-notif-badge');
            if (badge && newNotifs > 0) {
                badge.textContent = newNotifs > 9 ? '9+' : newNotifs;
                badge.style.display = 'block';
            }
        }
        updateUserNotifCounter();
        <?php endif; ?>
    </script>

</body>
</html>