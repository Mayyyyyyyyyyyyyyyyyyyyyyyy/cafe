<?php
session_start();

header('Content-Type: application/json');

$conn = new mysqli("localhost", "root", "", "cafe_amore_db");
if ($conn->connect_error) {

    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database connection failed.']);
    exit;
}


$data = json_decode(file_get_contents('php://input'), true);

$itemName = $data['item'] ?? '';
$price = $data['price'] ?? 0;
$paymentMethod = $data['paymentMethod'] ?? '';
$userId = $_SESSION['user_id'] ?? null; 
$quantity = 1; 


$price = floatval(preg_replace('/[^\d.]/', '', $price));

$stmt = $conn->prepare("INSERT INTO orders (user_id, item_name, price, quantity, payment_method) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("isdis", $userId, $itemName, $price, $quantity, $paymentMethod);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Order saved successfully.']);

    $notif_message = "New order placed for " . htmlspecialchars($itemName);
    $admin_notif_stmt = $conn->prepare("INSERT INTO notifications (type, message) VALUES ('new_order', ?)");
    $admin_notif_stmt->bind_param("s", $notif_message);
    $admin_notif_stmt->execute();

    
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        $user_notif_message = "Your order for " . htmlspecialchars($itemName) . " was successful.";
        $user_notif_stmt = $conn->prepare("INSERT INTO notifications (user_id, type, message) VALUES (?, 'new_order_user', ?)");
        $user_notif_stmt->bind_param("is", $user_id, $user_notif_message);
        $user_notif_stmt->execute();
    }
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to save order.']);
}

$stmt->close();
$conn->close();
?>