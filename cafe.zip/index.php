<!DOCTYPE html>
<?php
session_start();

// --- DATABASE CONNECTION ---
$conn = new mysqli("localhost", "root", "", "cafe_amore_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// --- FETCH FOOTER CONTENT ---
$footer_result = $conn->query("SELECT * FROM footer_content WHERE id = 1");
$footer_content = $footer_result->fetch_assoc();

// --- FETCH CUSTOMER FEEDBACK ---
$feedback_result = $conn->query("SELECT * FROM customer_feedback ORDER BY id DESC");
$customer_feedback = [];
if ($feedback_result) {
    while ($row = $feedback_result->fetch_assoc()) {
        $customer_feedback[] = $row;
    }
}

$conn->close();

// Helper function to extract social username
function get_social_username($url) { return basename(parse_url($url, PHP_URL_PATH)); }
?>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Café Amore | Home</title>
  <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    /* Styles for the new Customer Feedback section */
    #customer-feedback {
      background-color: #fdfaf6;
      padding: 80px 40px;
      opacity: 0;
      transform: translateY(30px);
      transition: opacity 0.8s ease-out, transform 0.8s ease-out;
    }
    #customer-feedback.visible {
      opacity: 1;
      transform: translateY(0);
    }
    #customer-feedback h2 {
      font-size: 2.5rem;
      margin-bottom: 40px;
    }
    .feedback-container {
      display: flex;
      justify-content: center;
      gap: 30px;
      flex-wrap: wrap;
    }
    .feedback-item {
      background: #fff;
      padding: 25px;
      border-radius: 12px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.07);
      max-width: 320px;
      text-align: left;
    }
    .feedback-item .quote {
      font-style: italic;
      color: #5a4634;
      margin-bottom: 15px;
    }
    .feedback-item .author {
      font-weight: bold;
      color: var(--accent-dark);
    }
    .footer-section.social p {
      font-size: 0.9rem; /* Smaller font size */
      margin: 5px 0;   /* Adjust spacing */
    }
  </style>
</head>
<body>
  <header>
    <nav class="navbar">
      <div class="logo"><span><img src="coffee-logo.png" alt=""></span> Café Amore</div>
      <ul class="nav-links" id="navLinks">
        <li><a href="index.php" class="active">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="menu.php">Menu</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="notification.php" title="Notification">
          <i class="fas fa-bell"></i><span class="notification-badge" id="user-notif-badge"></span>
        </a></li>
        <li><a href="setting.php" title="Settings"><i class="fas fa-cog"></i></a></li>
        <li><a href="login.php" title="Log Out"><i class="fas fa-sign-out-alt"></i></a></li>
      </ul>
      <div class="hamburger" id="hamburger">☰</div>
    </nav>
  </header>

  <main>
    <section class="carousel-container">
      <div class="carousel" id="carousel">
        <img src="slide1.jpg" alt="Cafe" />
        <img src="slide2.jpg" alt="Coffee" />
        <img src="slide3.jpg" alt="Dessert" />
      </div>
      <div class="carousel-text">
        <h1>Welcome to Café Amore</h1>
        <p>Your favorite spot for cozy brews and sweet bites!</p>
      </div>
    </section>

    <section id="customer-feedback">
      <h2>What Our Customers Say</h2>
      <div class="feedback-container" id="feedback-container">
        <?php if (!empty($customer_feedback)): ?>
            <?php foreach ($customer_feedback as $feedback): ?>
                <div class="feedback-item">
                    <p class="quote">"<?php echo htmlspecialchars($feedback['quote']); ?>"</p>
                    <p class="author"><?php echo htmlspecialchars($feedback['author']); ?></p>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <!-- This part is handled by the 'no-feedback' p tag below,
                 but you could also put a server-rendered message here. -->
        <?php endif; ?>
      </div>
      <p id="no-feedback" style="display: none; text-align: center; color: #888; margin-top: 20px;">No customer feedback has been posted yet.</p>
    </section>
  </main>

  <footer>
    <div class="footer-content">

        <!-- About Section -->
        <div class="footer-section about">
            <h3>About Café Amore</h3>
            <p><?php echo htmlspecialchars($footer_content['about_text']); ?></p>
        </div>

        <!-- Contact Section -->
        <div class="footer-section contact-info">
            <h3>Contact Us</h3>
            <?php if(!empty($footer_content['address'])): ?>
                <p><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($footer_content['address']); ?></p>
            <?php endif; ?>
            <?php if(!empty($footer_content['phone'])): ?>
                <p><i class="fas fa-phone"></i> <?php echo htmlspecialchars($footer_content['phone']); ?></p>
            <?php endif; ?>
            <?php if(!empty($footer_content['email'])): ?>
                <p><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($footer_content['email']); ?></p>
            <?php endif; ?>
        </div>

        <!-- Social Links Section -->
        <div class="footer-section social">
            <h3>Follow Us</h3>
            <?php if(!empty($footer_content['facebook_url'])): ?>
                <p><a href="<?php echo htmlspecialchars($footer_content['facebook_url']); ?>" target="_blank">
                    <i class="fab fa-facebook-f"></i> <?php echo get_social_username($footer_content['facebook_url']); ?>
                </a></p>
            <?php endif; ?>
            <?php if(!empty($footer_content['instagram_url'])): ?>
                <p><a href="<?php echo htmlspecialchars($footer_content['instagram_url']); ?>" target="_blank">
                    <i class="fab fa-instagram"></i> <?php echo get_social_username($footer_content['instagram_url']); ?>
                </a></p>
            <?php endif; ?>
            <?php if(!empty($footer_content['twitter_url'])): ?>
                <p><a href="<?php echo htmlspecialchars($footer_content['twitter_url']); ?>" target="_blank">
                    <i class="fab fa-twitter"></i> <?php echo get_social_username($footer_content['twitter_url']); ?>
                </a></p>
            <?php endif; ?>
        </div>

    </div>

    <div class="footer-bottom">
        <p>© 2025 Café Amore. All rights reserved.</p>
    </div>
</footer>


  <!-- Back to Top Arrow -->
  <button class="back-to-top" id="backToTopBtn"><i class="fas fa-arrow-up"></i></button>

  <script>
  document.addEventListener('DOMContentLoaded', function() {
    // --- LOGIN SUCCESS NOTIFICATION ---
    <?php
    // Check for the login success notification flag
    if (isset($_SESSION['login_success_notification']) && $_SESSION['login_success_notification']) {
        echo "
            const userNotifications = JSON.parse(localStorage.getItem('userNotifications')) || [];
            userNotifications.unshift({
                type: 'login_success',
                message: 'You have successfully logged in.',
                timestamp: new Date().toISOString()
            });
            localStorage.setItem('userNotifications', JSON.stringify(userNotifications.slice(0, 50)));
        ";
        // Unset the session flag so it doesn't trigger again on refresh
        unset($_SESSION['login_success_notification']);
    }
    ?>

    const hamburger = document.getElementById("hamburger");
    const navLinks = document.getElementById("navLinks");
    hamburger.addEventListener("click", () => navLinks.classList.toggle("show"));

    // Carousel functionality
    const carousel = document.querySelector('.carousel');
    if (carousel) {
        const totalImages = carousel.children.length;
        let index = 0;
        setInterval(() => {
            index = (index + 1) % totalImages;
            carousel.style.transform = `translateX(-${index * 100}%)`;
        }, 3000);
    }

    // Intersection Observer for feedback section animation
    const feedbackSection = document.getElementById("customer-feedback");
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                feedbackSection.classList.add("visible");
                observer.unobserve(feedbackSection);
            }
        });
    }, { threshold: 0.2 });
    observer.observe(feedbackSection);

    // Check if to show "no feedback" message
    const noFeedbackMessage = document.getElementById('no-feedback');
    const feedbackItems = document.querySelectorAll('.feedback-item');
    if (feedbackItems.length === 0) {
        noFeedbackMessage.style.display = 'block';
    }

    // Back to Top button
    const backToTopBtn = document.getElementById("backToTopBtn");
    window.addEventListener("scroll", () => {
        backToTopBtn.classList.toggle("show", window.scrollY > 200);
    });
    backToTopBtn.addEventListener("click", () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    // Notification counter
    function updateUserNotifCounter() {
        const lastCount = parseInt(localStorage.getItem('lastUserNotifCount') || 0);
        const contactMessages = JSON.parse(localStorage.getItem('contactMessages')) || [];
        const orderHistory = JSON.parse(localStorage.getItem('orderHistory')) || [];
        const userNotifications = JSON.parse(localStorage.getItem('userNotifications')) || [];
        const currentCount = contactMessages.length + orderHistory.length + userNotifications.length;
        const newNotifs = currentCount - lastCount;

        const badge = document.getElementById('user-notif-badge');
        if (badge && newNotifs > 0) {
            badge.textContent = newNotifs > 9 ? '9+' : newNotifs;
            badge.style.display = 'block';
        }
    }
    updateUserNotifCounter();
  });
</script>
