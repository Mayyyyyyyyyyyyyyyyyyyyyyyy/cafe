<?php
header('Content-Type: application/json');

$response = ['success' => false, 'message' => 'Invalid request.'];

// Get the posted data
$data = json_decode(file_get_contents('php://input'), true);

$quote = $data['quote'] ?? null;
$author = $data['author'] ?? null;

if ($quote && $author) {
    $conn = new mysqli("localhost", "root", "", "cafe_amore_db");
    if ($conn->connect_error) {
        $response['message'] = "Database connection failed.";
    } else {
        $stmt = $conn->prepare("INSERT INTO customer_feedback (quote, author) VALUES (?, ?)");
        $stmt->bind_param("ss", $quote, $author);

        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = 'Feedback posted successfully!';
        } else {
            $response['message'] = 'Database error: ' . $stmt->error;
        }
        $stmt->close();
        $conn->close();
    }
}

echo json_encode($response);
?>