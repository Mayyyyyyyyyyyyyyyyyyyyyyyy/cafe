<?php
header('Content-Type: application/json');
$response = ['success' => false, 'message' => 'Invalid request.'];

$data = json_decode(file_get_contents('php://input'), true);
$notifId = $data['id'] ?? null;

if ($notifId) {
    $conn = new mysqli("localhost", "root", "", "cafe_amore_db");
    if ($conn->connect_error) {
        $response['message'] = "Database connection failed.";
    } else {
        $stmt = $conn->prepare("DELETE FROM notifications WHERE id = ?");
        $stmt->bind_param("i", $notifId);
        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = 'Notification deleted.';
        } else {
            $response['message'] = 'Database error: ' . $stmt->error;
        }
        $stmt->close();
        $conn->close();
    }
}

echo json_encode($response);
?>