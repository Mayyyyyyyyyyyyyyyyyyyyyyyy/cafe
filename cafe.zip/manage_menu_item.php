<?php
header('Content-Type: application/json');

$response = ['success' => false, 'message' => 'Invalid request.'];

$conn = new mysqli("localhost", "root", "", "cafe_amore_db");
if ($conn->connect_error) {
    $response['message'] = "Database connection failed.";
    echo json_encode($response);
    exit();
}

$action = $_POST['action'] ?? '';

if ($action === 'save') {
    $id = $_POST['id'] ?? null;
    $name = $_POST['name'] ?? '';
    $price = $_POST['price'] ?? 0;
    $image_path = '';

    // Handle file upload
    if (isset($_FILES['image'])) {
        $file = $_FILES['image'];
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/jfif'];
        if (in_array($file['type'], $allowedTypes) && $file['error'] === UPLOAD_ERR_OK) {
            $newFileName = uniqid('menu_') . '_' . basename($file['name']);
            $uploadPath = __DIR__ . '/' . $newFileName;
            if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
                $image_path = $newFileName;
            }
        }
    }

    if ($id) { // Update existing item
        if ($image_path) { 
            $stmt = $conn->prepare("UPDATE menu_items SET name = ?, price = ?, image = ? WHERE id = ?");
            $stmt->bind_param("sdsi", $name, $price, $image_path, $id);
        } else { // If no new image
            $stmt = $conn->prepare("UPDATE menu_items SET name = ?, price = ? WHERE id = ?");
            $stmt->bind_param("sdi", $name, $price, $id);
        }
    } else { 
        $image_path = $image_path ?: 'default.png'; 
        $stmt = $conn->prepare("INSERT INTO menu_items (name, price, image) VALUES (?, ?, ?)");
        $stmt->bind_param("sds", $name, $price, $image_path);
    }

    if ($stmt->execute()) {
        $response['success'] = true;
        $response['message'] = 'Item saved successfully!';

        if (!$id) {
            // Notification for ADMIN
            $admin_notif_message = "New menu item added: " . htmlspecialchars($name);
            $admin_notif_stmt = $conn->prepare("INSERT INTO notifications (type, message) VALUES ('new_menu_item', ?)");
            $admin_notif_stmt->bind_param("s", $admin_notif_message);
            $admin_notif_stmt->execute();

            // Notification for ALL USERS (broadcast)
            $user_notif_message = "Check out our new item: " . htmlspecialchars($name) . "!";
            $user_ids_result = $conn->query("SELECT id FROM users");
            if ($user_ids_result) {
                $user_notif_stmt = $conn->prepare("INSERT INTO notifications (user_id, type, message) VALUES (?, 'new_menu_item_user', ?)");
                while ($user_row = $user_ids_result->fetch_assoc()) {
                    $user_id = $user_row['id'];
                    $user_notif_stmt->bind_param("is", $user_id, $user_notif_message);
                    $user_notif_stmt->execute();
                }
            }
        }
    } else {
        $response['message'] = 'Database error: ' . $stmt->error;
    }
    $stmt->close();

} elseif ($action === 'delete') {
    $id = $_POST['id'] ?? null;
    if ($id) {
        
        $stmt = $conn->prepare("SELECT image FROM menu_items WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->bind_result($image_to_delete);
        $stmt->fetch();
        $stmt->close();

        
        $delete_stmt = $conn->prepare("DELETE FROM menu_items WHERE id = ?");
        $delete_stmt->bind_param("i", $id);
        if ($delete_stmt->execute()) {
    
            if ($image_to_delete && file_exists(__DIR__ . '/' . $image_to_delete)) {
                unlink(__DIR__ . '/' . $image_to_delete);
            }
            $response['success'] = true;
            $response['message'] = 'Item deleted successfully!';
        } else {
            $response['message'] = 'Failed to delete item.';
        }
        $delete_stmt->close();
    }
}

$conn->close();
echo json_encode($response);
?>