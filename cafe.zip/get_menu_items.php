<?php
header('Content-Type: application/json');

$conn = new mysqli("localhost", "root", "", "cafe_amore_db");

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed: ' . $conn->connect_error]);
    exit();
}

$result = $conn->query("SELECT id, name, price, image FROM menu_items ORDER BY id");
$items = $result->fetch_all(MYSQLI_ASSOC);

echo json_encode($items);
$conn->close();
?>