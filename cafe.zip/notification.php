<?php

session_start();


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// --- DATABASE CONNECTION ---
$conn = new mysqli("localhost", "root", "", "cafe_amore_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$footer_result = $conn->query("SELECT * FROM footer_content WHERE id = 1");
$footer_content = $footer_result->fetch_assoc();

$user_id = $_SESSION['user_id'];
$notif_result = $conn->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC");
$notif_result->bind_param("i", $user_id);
$notif_result->execute();
$notifications = $notif_result->get_result()->fetch_all(MYSQLI_ASSOC);

$conn->close();

function get_social_username($url) {
    return basename(parse_url($url, PHP_URL_PATH));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Café Amore | Notifications</title>
  <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    #notifications-section {
      padding: 100px 20px 60px;
      max-width: 900px;
      margin: 0 auto;
      text-align: center;
    }
    #notifications-section h2 {
      font-size: 2.5rem;
      color: var(--accent-dark);
      margin-bottom: 40px;
    }
    .notifications-container {
      text-align: left;
    }
    .notification-item {
      background: #fff;
      border-radius: 10px;
      padding: 20px;
      margin-bottom: 15px;
      display: flex;
      align-items: center;
      gap: 20px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.08);
      transition: transform 0.2s, box-shadow 0.2s;
    }
    .notification-item:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 25px rgba(0,0,0,0.12);
    }
    .notification-item a { text-decoration: none; color: inherit; display: contents; }
    .notification-icon {
      font-size: 1.8rem;
      color: var(--accent);
      width: 40px;
      text-align: center;
    }
    .notification-content {
      flex-grow: 1;
    }
    .notification-content p {
      margin: 0;
      font-size: 1.1rem;
      color: var(--text);
    }
    .notification-content .timestamp {
      font-size: 0.85rem;
      color: #888;
      margin-top: 5px;
    }
    .delete-notification-btn {
      background: none;
      border: none;
      color: #aaa;
      font-size: 1.2rem;
      margin-left: auto;
      cursor: pointer;
      transition: color 0.2s;
    }
    .delete-notification-btn:hover {
      color: #dc3545;
    }
    #no-notifications {
      font-size: 1.2rem;
      color: #888;
      padding: 40px;
    }

    
    .message-modal {
      display: none;
      position: fixed;
      z-index: 1000;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0,0,0,0.5);
      justify-content: center;
      align-items: center;
    }
    .message-modal-content {
      background-color: #fefefe;
      padding: 30px;
      border-radius: 10px;
      width: 90%;
      max-width: 500px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.3);
      position: relative;
    }
    .close-modal {
      position: absolute;
      top: 10px;
      right: 20px;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
    }
    .footer-section.social p {
      font-size: 0.9rem; 
      margin: 5px 0;   
    }
  </style>
</head>
<body>
  <header>
    <nav class="navbar">
      <div class="logo"><span><img src="coffee-logo.png" alt=""></span> Café Amore</div>
      <ul class="nav-links" id="navLinks">
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="menu.php">Menu</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="notification.php" class="active" title="Notification">
          <i class="fas fa-bell"></i><span class="notification-badge" id="user-notif-badge"></span>
        </a></li>
        <li>
          <a href="setting.php" title="Settings"><i class="fas fa-cog"></i></a>
        </li>
        <li><a href="login.php" title="Log Out"><i class="fas fa-sign-out-alt"></i></a></li>
      </ul>
      <div class="hamburger" id="hamburger">☰</div>
    </nav>
  </header>

  <main>
    <section id="notifications-section">
      <h2>Notifications</h2>
      <div class="notifications-container" id="notificationsContainer">
        <?php if (!empty($notifications)): ?>
          <?php foreach ($notifications as $notif):
              $iconClass = 'fas fa-bell'; // Default icon
              if ($notif['type'] === 'new_order_user') $iconClass = 'fas fa-receipt';
              if ($notif['type'] === 'message_sent') $iconClass = 'fas fa-paper-plane';
              if ($notif['type'] === 'new_menu_item_user') $iconClass = 'fas fa-utensils';
              if ($notif['type'] === 'login_success') $iconClass = 'fas fa-user-check';
          ?>
            <div class="notification-item">
              <div class="notification-icon"><i class="<?php echo $iconClass; ?>"></i></div>
              <div class="notification-content">
                <p><?php echo htmlspecialchars($notif['message']); ?></p>
                <div class="timestamp"><?php echo date('F j, Y, g:i a', strtotime($notif['created_at'])); ?></div>
              </div>
              <button class="delete-notification-btn" data-id="<?php echo $notif['id']; ?>" title="Delete Notification"><i class="fas fa-trash-alt"></i></button>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
      <?php if (empty($notifications)): ?><p id="no-notifications">You have no new notifications.</p><?php endif; ?>
    </section>
  </main>

  
  <div id="messageModal" class="message-modal">
    <div class="message-modal-content">
      <span class="close-modal">&times;</span>
      <div id="messageModalBody"></div>
    </div>
  </div>

  <footer>
    <div class="footer-content">
      
      <div class="footer-section about">
        <h3>About Café Amore</h3>
        <p><?php echo htmlspecialchars($footer_content['about_text']); ?></p>
      </div>
      <!-- Contact Section -->
      <div class="footer-section contact-info">
        <h3>Contact Us</h3>
        <?php if (!empty($footer_content['address'])): ?><p><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($footer_content['address']); ?></p><?php endif; ?>
        <?php if (!empty($footer_content['phone'])): ?><p><i class="fas fa-phone"></i> <?php echo htmlspecialchars($footer_content['phone']); ?></p><?php endif; ?>
        <?php if (!empty($footer_content['email'])): ?><p><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($footer_content['email']); ?></p><?php endif; ?>
      </div>
      <!-- Social Section -->
      <div class="footer-section social">
        <h3>Follow Us</h3>
        <?php if (!empty($footer_content['facebook_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['facebook_url']); ?>" target="_blank"><i class="fab fa-facebook-f"></i> <?php echo get_social_username($footer_content['facebook_url']); ?></a></p><?php endif; ?>
        <?php if (!empty($footer_content['instagram_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['instagram_url']); ?>" target="_blank"><i class="fab fa-instagram"></i> <?php echo get_social_username($footer_content['instagram_url']); ?></a></p><?php endif; ?>
        <?php if (!empty($footer_content['twitter_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['twitter_url']); ?>" target="_blank"><i class="fab fa-twitter"></i> <?php echo get_social_username($footer_content['twitter_url']); ?></a></p><?php endif; ?>
      </div>
    </div>
    <div class="footer-bottom">
      <p>© 2025 Café Amore. All rights reserved.</p>
    </div>
  </footer>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const hamburger = document.getElementById("hamburger");
      const navLinks = document.getElementById("navLinks");
      hamburger.addEventListener("click", () => navLinks.classList.toggle("show"));

      const notificationsContainer = document.getElementById('notificationsContainer');

      notificationsContainer.addEventListener('click', function(e) {
        const deleteButton = e.target.closest('.delete-notification-btn');
        if (deleteButton) {
          const notifId = deleteButton.dataset.id;

          if (confirm('Are you sure you want to delete this notification?')) {
            fetch('delete_notification.php', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ id: notifId })
            })
            .then(response => response.json())
            .then(data => {
              if (data.success) {
                deleteButton.closest('.notification-item').remove();
                
                if (notificationsContainer.children.length === 0) {
                  const noNotifEl = document.getElementById('no-notifications') || document.createElement('p');
                  noNotifEl.id = 'no-notifications';
                  noNotifEl.textContent = 'You have no new notifications.';
                  notificationsContainer.appendChild(noNotifEl);
                }
              } else {
                alert('Error: ' + data.message);
              }
            });
          }
        }
      });
    });
  </script>
</body>
</html>