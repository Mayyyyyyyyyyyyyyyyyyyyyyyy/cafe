<?php
// --- DATABASE CONNECTION ---
$conn = new mysqli("localhost", "root", "", "cafe_amore_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// --- FETCH CONTENT FROM DATABASE ---
$result = $conn->query("SELECT image_path, paragraphs FROM about_content WHERE id = 1");
$content = $result->fetch_assoc();


$footer_result = $conn->query("SELECT * FROM footer_content WHERE id = 1");
$footer_content = $footer_result->fetch_assoc();

$image = htmlspecialchars($content['image_path']);
$paragraphs = json_decode($content['paragraphs'], true);

$conn->close();


function get_social_username($url) {
    return basename(parse_url($url, PHP_URL_PATH));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Café Amore | Admin About</title>
  <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    .footer-section.social p {
      font-size: 0.9rem; 
      margin: 5px 0;   
    }
    .about-image { cursor: pointer; }
    .about-text p { cursor: pointer; }
    .save-btn {
        display: none;  margin: 20px auto; padding: 10px 25px;
        font-size: 1rem; background-color: #4CAF50; color: white;
        border: none; border-radius: 5px; cursor: pointer;
    }
    .save-btn:hover { background-color: #45a049; }
    #saveStatus {
      text-align: center;
      margin-top: 15px;
      font-weight: bold;
    }
  </style>
</head>
<body>
  <header>
    <nav class="navbar">
      <div class="logo"><span class="animated-cup"></span> Café Amore</div>
      <ul class="nav-links" id="navLinks">
        <li><a href="AdminDashboard.php">Home</a></li>
        <li><a href="AdminAbout.php" class="active">About</a></li>
        <li><a href="AdminMenu.php">Menu</a></li>
        <li><a href="AdminContact.php">Contact</a></li>
        <li><a href="AdminNotif.php" title="Activity Log"><i class="fas fa-bell"></i></a></li>
        
        <li><a href="login.php" title="Log Out"><i class="fas fa-sign-out-alt"></i></a></li>
      </ul>
      <div class="hamburger" id="hamburger">☰</div>
    </nav>
  </header>

  <main>
    <section id="about">
      <h2 style="text-align:center; font-size: 2.5rem; margin-bottom: 30px;">Manage About Page</h2>
      <div class="about-container">
        <div class="about-image" id="imageContainer" title="Click to upload new image">
          <img src="<?php echo $image; ?>" alt="Interior of Café Amore" id="aboutImage">
          <input type="file" id="imageUpload" style="display: none;" accept="image/*">
        </div>
        <div class="about-text" id="textContainer">
          <h2>Our Story</h2>
          <?php foreach ($paragraphs as $paragraph): ?>
            <p contenteditable="false" ondblclick="this.contentEditable=true; this.focus(); showSaveButton();" title="Double-click to edit"><?php echo htmlspecialchars($paragraph); ?></p>
          <?php endforeach; ?>
        </div>
      </div>
      <button id="saveBtn" class="save-btn">Save Changes</button>
      <p id="saveStatus"></p>
    </section>
  </main>

  <footer>
    <div class="footer-content">
      
      <div class="footer-section about">
        <h3>About Café Amore</h3>
        <p><?php echo htmlspecialchars($footer_content['about_text']); ?></p>
      </div>
    
      <div class="footer-section contact-info">
        <h3>Contact Us</h3>
        <?php if (!empty($footer_content['address'])): ?><p><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($footer_content['address']); ?></p><?php endif; ?>
        <?php if (!empty($footer_content['phone'])): ?><p><i class="fas fa-phone"></i> <?php echo htmlspecialchars($footer_content['phone']); ?></p><?php endif; ?>
        <?php if (!empty($footer_content['email'])): ?><p><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($footer_content['email']); ?></p><?php endif; ?>
      </div>
    
      <div class="footer-section social">
        <h3>Follow Us</h3>
        <?php if (!empty($footer_content['facebook_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['facebook_url']); ?>" target="_blank"><i class="fab fa-facebook-f"></i> <?php echo get_social_username($footer_content['facebook_url']); ?></a></p><?php endif; ?>
        <?php if (!empty($footer_content['instagram_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['instagram_url']); ?>" target="_blank"><i class="fab fa-instagram"></i> <?php echo get_social_username($footer_content['instagram_url']); ?></a></p><?php endif; ?>
        <?php if (!empty($footer_content['twitter_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['twitter_url']); ?>" target="_blank"><i class="fab fa-twitter"></i> <?php echo get_social_username($footer_content['twitter_url']); ?></a></p><?php endif; ?>
      </div>
    </div>
    <div class="footer-bottom">
      <p>© 2025 Café Amore. All rights reserved.</p>
    </div>
  </footer>

  
  <button class="back-to-top" id="backToTopBtn"><i class="fas fa-arrow-up"></i></button>

  <script>
    const hamburger = document.getElementById("hamburger");
    const navLinks = document.getElementById("navLinks");
    hamburger.addEventListener("click", () => navLinks.classList.toggle("show"));
    
    const backToTopBtn = document.getElementById("backToTopBtn");
    window.addEventListener("scroll", () => {
      backToTopBtn.classList.toggle("show", window.scrollY > 200);
    });
    backToTopBtn.addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    
    const imageContainer = document.getElementById('imageContainer');
    const imageUpload = document.getElementById('imageUpload');
    const aboutImage = document.getElementById('aboutImage');
    const saveBtn = document.getElementById('saveBtn');
    const textContainer = document.getElementById('textContainer');
    const saveStatus = document.getElementById('saveStatus');

    function showSaveButton() {
        saveBtn.style.display = 'block';
    }

    
    imageContainer.addEventListener('click', () => imageUpload.click());

  
    imageUpload.addEventListener('change', (event) => {
      showSaveButton(); 
      const file = event.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          aboutImage.src = e.target.result;
        };
        reader.readAsDataURL(file);
      }
    });

    // Save all changes
    saveBtn.addEventListener('click', () => {
      saveStatus.textContent = 'Saving...';
      saveStatus.style.color = 'orange';

      const paragraphs = Array.from(textContainer.querySelectorAll('p')).map(p => p.innerText);
      const imageFile = imageUpload.files[0];

      const formData = new FormData();
      
      formData.append('paragraphs', JSON.stringify(paragraphs));
      if (imageFile) {
        formData.append('image', imageFile);
      }

      fetch('save_about_db.php', { 
        method: 'POST',
        body: formData
      })
      .then(response => response.json())
      .then(data => {
        saveStatus.textContent = data.message;
        saveStatus.style.color = data.success ? 'green' : 'red';
        if (data.success) {
          if (data.newImagePath) {
            
            aboutImage.src = data.newImagePath + '?' + new Date().getTime();
          }
          
          const adminNotifications = JSON.parse(localStorage.getItem('adminNotifications')) || [];
          adminNotifications.unshift({
              type: 'about_update',
              message: 'The "About Us" page content was successfully updated.',
              timestamp: new Date().toLocaleString()
          });
      
          localStorage.setItem('adminNotifications', JSON.stringify(adminNotifications.slice(0, 50)));
          
          setTimeout(() => {
            saveBtn.style.display = 'none';
            saveStatus.textContent = '';
          }, 2000); 
        }
      })
      .catch(error => console.error('Error:', error));
    });
  </script>
</body>
</html>
