<?php
header('Content-Type: application/json');

$response = ['success' => false, 'message' => 'Invalid request.'];


$data = json_decode(file_get_contents('php://input'), true);
$messageId = $data['id'] ?? null;

if ($messageId) {
    $conn = new mysqli("localhost", "root", "", "cafe_amore_db");
    if ($conn->connect_error) {
        $response['message'] = "Database connection failed.";
    } else {
        
        $conn->begin_transaction();

        try {
    
            $stmt_get = $conn->prepare("SELECT name, message FROM contact_messages WHERE id = ?");
            $stmt_get->bind_param("i", $messageId);
            $stmt_get->execute();
            $stmt_get->bind_result($name, $message);
            $stmt_get->fetch();
            $stmt_get->close();

            if ($name && $message) {
        
                $author = '- ' . $name;
                $stmt_del_feedback = $conn->prepare("DELETE FROM customer_feedback WHERE quote = ? AND author = ?");
                $stmt_del_feedback->bind_param("ss", $message, $author);
                $stmt_del_feedback->execute();
                $stmt_del_feedback->close();
            }

            $stmt_del_message = $conn->prepare("DELETE FROM contact_messages WHERE id = ?");
            $stmt_del_message->bind_param("i", $messageId);
            $stmt_del_message->execute();
            $stmt_del_message->close();


            $conn->commit();
            $response['success'] = true;
            $response['message'] = 'Message and any associated feedback have been deleted successfully!';
        } catch (mysqli_sql_exception $exception) {
            $conn->rollback();
            $response['message'] = 'Database error: ' . $exception->getMessage();
        }
        $conn->close();
    }
}

echo json_encode($response);
?>