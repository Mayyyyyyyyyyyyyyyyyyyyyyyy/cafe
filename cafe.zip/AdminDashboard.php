<?php
$conn = new mysqli("localhost", "root", "", "cafe_amore_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sales_query = "SELECT DATE(order_date) as sale_date, SUM(price) as total_sales FROM orders GROUP BY DATE(order_date) ORDER BY sale_date ASC";
$sales_result = $conn->query($sales_query);

$sales_data = [];
if ($sales_result) {
    while ($row = $sales_result->fetch_assoc()) {
        $sales_data[] = $row;
    }
}
$count_result = $conn->query("SELECT COUNT(*) as unread_count FROM notifications WHERE is_read = 0");
$notif_count = 0;
if ($count_result) {
    $notif_count = $count_result->fetch_assoc()['unread_count'];
}

$feedback_result = $conn->query("SELECT * FROM customer_feedback ORDER BY id DESC");
$customer_feedback = [];
if ($feedback_result) {
    while ($row = $feedback_result->fetch_assoc()) {
        $customer_feedback[] = $row;
    }
}

$footer_result = $conn->query("SELECT * FROM footer_content WHERE id = 1");
$footer_content = $footer_result->fetch_assoc();

$top_items_query = "
    SELECT item_name, SUM(quantity) as total_quantity
    FROM orders
    GROUP BY item_name
    ORDER BY total_quantity DESC
    LIMIT 5
";
$top_items_result = $conn->query($top_items_query);

$top_customers_query = "
    SELECT u.username, COUNT(o.id) as order_count, SUM(o.price * o.quantity) as total_spent
    FROM orders o
    JOIN users u ON o.user_id = u.id
    WHERE o.user_id IS NOT NULL
    GROUP BY o.user_id, u.username
    ORDER BY total_spent DESC
    LIMIT 5
";
$top_customers_result = $conn->query($top_customers_query);
$limit = 10; 
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;
$search = isset($_GET['search']) ? $_GET['search'] : '';

$order_query = "
    SELECT o.id, u.username, u.email, o.item_name, o.quantity, o.order_date
    FROM orders o
    LEFT JOIN users u ON o.user_id = u.id
";

if (!empty($search)) {
    $order_query .= " WHERE u.username LIKE ? OR u.email LIKE ? OR o.item_name LIKE ?";
}

$order_query .= " ORDER BY o.order_date DESC LIMIT ? OFFSET ?";

$stmt = $conn->prepare($order_query);

if (!empty($search)) {
    $search_param = "%{$search}%";
    $stmt->bind_param("sssii", $search_param, $search_param, $search_param, $limit, $offset);
} else {
    $stmt->bind_param("ii", $limit, $offset);
}

$stmt->execute();
$order_history_result = $stmt->get_result();

$conn->close();

function get_social_username($url) { return basename(parse_url($url, PHP_URL_PATH)); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin Dashboard | Café Amore</title>
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
      
      main {
        padding-top: 80px;
        flex: 1;
      }
      
      #customer-feedback {
        background-color: #fdfaf6;
        padding: 80px 40px;
      }
      #customer-feedback h2 {
        font-size: 2.5rem;
        margin-bottom: 40px;
      }
      .feedback-container {
        display: flex;
        justify-content: center;
        gap: 30px;
        flex-wrap: wrap;
      }
      .feedback-item {
        background: #fff;
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0 8px 20px rgba(0,0,0,0.07);
        max-width: 320px;
        text-align: left;
      }
      .feedback-item .quote { font-style: italic; color: #5a4634; margin-bottom: 15px; }
      .feedback-item .author { font-weight: bold; color: var(--accent-dark); }

      .dashboard-section h2 {
        font-size: 2rem;
        margin-bottom: 1.5rem;
        color: #5a4634;
        text-align: center;
      }
      .feedback-container {
        display: flex;
        justify-content: center;
        gap: 30px;
        flex-wrap: wrap;
      }
      .feedback-item {
        background: #fff;
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0 8px 20px rgba(0,0,0,0.07);
        max-width: 320px;
        text-align: left;
        border: 1px solid #eee;
      }
      .feedback-item .quote {
        font-style: italic;
        color: #5a4634;
        margin-bottom: 15px;
      }
      .feedback-item .author {
        font-weight: bold;
        color: var(--accent-dark);
      }
      
      footer { position: relative; }
      .edit-icon-footer {
        position: absolute;
        top: 20px;
        left: 20px;
        font-size: 1.5rem;
        color: #fff;
        cursor: pointer;
        z-index: 10;
        transition: color 0.3s;
      }
      .edit-icon-footer:hover { color: #f7e7ce; }

      .edit-modal {
        position: fixed;
        top: 0; left: 0;
        width: 100%; height: 100%;
        background: rgba(0,0,0,0.6);
        display: none;
        justify-content: center;
        align-items: center;
        z-index: 2000;
      }
      .edit-modal-content {
        background: #fff;
        padding: 30px;
        border-radius: 10px;
        width: 90%;
        max-width: 600px;
        color: var(--text);
      }
      .edit-modal-content h2 { margin-bottom: 20px; color: var(--accent-dark); }
      .edit-modal .form-group { margin-bottom: 15px; }
      .edit-modal label { font-weight: bold; margin-bottom: 5px; display: block; }
      .edit-modal-content input,
      .edit-modal-content textarea {
        width: 100%;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
      }
      .edit-modal-buttons { text-align: right; margin-top: 20px; }
      .edit-modal-buttons button {
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        margin-left: 10px;
      }

      .order-history-section {
        padding: 40px 2rem;
        background-color: #fff;
      }
      .table-controls {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
      }
      .search-form {
        display: flex;
        gap: 10px;
      }
      .search-form input {
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
      }
      .search-form button {
        padding: 10px 15px;
        border: none;
        background-color: var(--accent);
        color: white;
        border-radius: 5px;
        cursor: pointer;
      }
      .order-history-table {
        width: 100%;
        border-collapse: collapse;
        box-shadow: 0 2px 15px rgba(0,0,0,0.1);
      }
      .order-history-table th, .order-history-table td {
        padding: 12px 15px;
        border: 1px solid #ddd;
        text-align: left;
      }
      .order-history-table thead {
        background-color: var(--accent-dark);
        color: white;
      }
      .pagination {
        margin-top: 20px;
        text-align: right;
      }
      .pagination a {
        color: var(--accent-dark);
        padding: 8px 16px;
        text-decoration: none;
        border: 1px solid #ddd;
        margin: 0 4px;
        border-radius: 4px;
      }
      .pagination a.active {
        background-color: var(--accent);
        color: white;
        border-color: var(--accent);
      }
      .pagination a.disabled {
        color: #ccc;
        pointer-events: none;
      }
    </style>
    <style>
      
      .dashboard-widgets {
        display: flex;
        gap: 2rem;
        padding: 40px 2rem;
        justify-content: center;
        flex-wrap: wrap;
      }
      .widget {
        flex: 1;
        min-width: 350px;
        max-width: 500px;
        background: #fff;
      }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="logo"><span><img src="coffee-logo.png" alt=""></span> Café Amore</div>
            <ul class="nav-links" id="navLinks">
                <li><a href="AdminDashboard.php" class="active">Home</a></li>
                <li><a href="AdminAbout.php">About</a></li>
                <li><a href="AdminMenu.php">Menu</a></li>
                <li><a href="AdminContact.php">Contact</a></li>
                <li><a href="AdminNotif.php" title="Activity Log" style="position: relative;">
                    <i class="fas fa-bell"></i>
                    <?php if ($notif_count > 0): ?>
                        <span class="notification-badge"><?php echo $notif_count > 9 ? '9+' : $notif_count; ?></span>
                    <?php endif; ?>
                </a></li>
            
                <li><a href="login.php" title="Log Out"><i class="fas fa-sign-out-alt"></i></a></li>
            </ul>
            <div class="hamburger" id="hamburger">☰</div>
        </nav>
    </header>

    <main>
        <section class="carousel-container">
            <div class="carousel" id="carousel">
                <img src="slide1.jpg" alt="Cafe" />
                <img src="slide2.jpg" alt="Coffee" />
                <img src="slide3.jpg" alt="Dessert" />
            </div>
            <div class="carousel-text">
                <h1>Welcome, Admin!</h1>
                <p>Manage your café with ease.</p>
            </div>
        </section>

        <section id="customer-feedback">
            <h2>Customer Comments</h2>
            <div class="feedback-container" id="feedback-container">
                <?php if (!empty($customer_feedback)): ?>
                    <?php foreach ($customer_feedback as $feedback): ?>
                        <div class="feedback-item">
                            <p class="quote">"<?php echo htmlspecialchars($feedback['quote']); ?>"</p>
                            <p class="author"><?php echo htmlspecialchars($feedback['author']); ?></p>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <p id="no-feedback" style="display: none; text-align: center; color: #888;">No customer feedback has been posted yet.</p>
        </section>

        <!-- Sales Chart Section -->
        <div class="dashboard-container" style="padding: 0 2rem;">
            <div class="dashboard-section">
                <h2>Daily Sales Report</h2>
                <div style="max-width: 900px; margin: 0 auto;">
                    <canvas id="salesChart"></canvas>
                </div>
            </div>
         </div>

        
        <div class="dashboard-widgets">
            
            <div class="widget">
                <div class="dashboard-section">
                    <h2>Top Selling Items</h2>
                    <table class="order-history-table">
                        <thead>
                            <tr>
                                <th>Item Name</th>
                                <th>Total Quantity Sold</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($item = $top_items_result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['item_name']); ?></td>
                                <td><?php echo $item['total_quantity']; ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            
            <div class="widget">
                <div class="dashboard-section">
                    <h2>Top Customers</h2>
                    <table class="order-history-table">
                        <thead><tr><th>Username</th><th>Total Orders</th><th>Total Spent</th></tr></thead>
                        <tbody>
                            <?php while($customer = $top_customers_result->fetch_assoc()): ?>
                            <tr><td><?php echo htmlspecialchars($customer['username']); ?></td><td><?php echo $customer['order_count']; ?></td><td>₱<?php echo number_format($customer['total_spent'], 2); ?></td></tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        
        <section class="order-history-section">
            <h2>Order History</h2>
            <div class="table-controls">
                <form action="AdminDashboard.php" method="GET" class="search-form">
                    <input type="text" name="search" placeholder="Search by user, email, or item..." value="<?php echo htmlspecialchars($search); ?>">
                    <button type="submit">Search</button>
                </form>
            </div>

            <table class="order-history-table">
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Order Name</th>
                        <th>Quantity</th>
                        <th>Date Ordered</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($order_history_result->num_rows > 0): ?>
                        <?php while($row = $order_history_result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['username'] ?? 'Guest'); ?></td>
                                <td><?php echo htmlspecialchars($row['email'] ?? 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars($row['item_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['quantity']); ?></td>
                                <td><?php echo date('F j, Y, g:i a', strtotime($row['order_date'])); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" style="text-align:center;">No orders found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <div class="pagination">
                <a href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>" class="<?php echo ($page <= 1) ? 'disabled' : ''; ?>">Prev</a>
                <a href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>" class="<?php echo ($order_history_result->num_rows < $limit) ? 'disabled' : ''; ?>">Next</a>
            </div>
        </section>
    </main>

    <footer>
        <a class="edit-icon-footer" id="editFab"><i class="fas fa-edit"></i></a>
        <div class="footer-content">
            <div class="footer-section about">
                <h3>About Café Amore</h3>
                <p id="footer-about-p"><?php echo htmlspecialchars($footer_content['about_text']); ?></p>
            </div>
            <div class="footer-section contact-info">
                <h3>Contact Us</h3>
                <p><i class="fas fa-map-marker-alt"></i> <span id="footer-address"><?php echo htmlspecialchars($footer_content['address']); ?></span></p>
                <p><i class="fas fa-phone"></i> <span id="footer-phone"><?php echo htmlspecialchars($footer_content['phone']); ?></span></p>
                <p><i class="fas fa-envelope"></i> <span id="footer-email"><?php echo htmlspecialchars($footer_content['email']); ?></span></p>
            </div>
            <div class="footer-section social">
                <h3>Follow Us</h3>
                <p><a href="<?php echo htmlspecialchars($footer_content['facebook_url']); ?>" id="footer-facebook-link" target="_blank"><i class="fab fa-facebook-f"></i> <?php echo get_social_username($footer_content['facebook_url']); ?></a></p>
                <p><a href="<?php echo htmlspecialchars($footer_content['instagram_url']); ?>" id="footer-instagram-link" target="_blank"><i class="fab fa-instagram"></i> <?php echo get_social_username($footer_content['instagram_url']); ?></a></p>
                <p><a href="<?php echo htmlspecialchars($footer_content['twitter_url']); ?>" id="footer-twitter-link" target="_blank"><i class="fab fa-twitter"></i> <?php echo get_social_username($footer_content['twitter_url']); ?></a></p>
            </div>
        </div>

        <div class="footer-bottom">
            <p>© 2025 Café Amore. All rights reserved.</p>
        </div>
    </footer>

    <div id="editModal" class="edit-modal">
      <div class="edit-modal-content">
        <h2>Edit Footer Content</h2>
        <form id="editForm">
          <div class="form-group">
            <label for="aboutText">About Section Paragraph</label>
            <textarea id="aboutText" rows="3"></textarea>
          </div>
          <div class="form-group">
            <label for="addressText">Address</label>
            <input type="text" id="addressText">
          </div>
          <div class="form-group">
            <label for="phoneText">Phone</label>
            <input type="text" id="phoneText">
          </div>
          <div class="form-group">
            <label for="emailText">Email</label>
            <input type="text" id="emailText">
          </div>
          <div class="form-group">
            <label for="facebookLink">Facebook URL</label>
            <input type="text" id="facebookLink">
          </div>
          <div class="form-group">
            <label for="instagramLink">Instagram URL</label>
            <input type="text" id="instagramLink">
          </div>
          <div class="form-group">
            <label for="twitterLink">Twitter URL</label>
            <input type="text" id="twitterLink">
          </div>
          <div class="edit-modal-buttons">
            <button type="button" id="cancelModalBtn" style="background-color: #6c757d; color: white;">Cancel</button>
            <button type="button" id="saveChangesBtn" style="background-color: #28a745; color: white;">Save Changes</button>
          </div>
        </form>
      </div>
    </div>

    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const hamburger = document.getElementById("hamburger");
        const navLinks = document.getElementById("navLinks");
        hamburger.addEventListener("click", () => navLinks.classList.toggle("show"));

        
        const carousel = document.querySelector('.carousel');
        if (carousel) {
            const totalImages = carousel.children.length;
            let index = 0;
            setInterval(() => {
                index = (index + 1) % totalImages;
                carousel.style.transform = `translateX(-${index * 100}%)`;
            }, 3000);
        }
        
        const salesData = <?php echo json_encode($sales_data); ?>;
        const labels = salesData.map(item => item.sale_date);
        const data = salesData.map(item => item.total_sales);

        const ctx = document.getElementById('salesChart').getContext('2d');
        const salesChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Total Sales (₱)',
                    data: data,
                    backgroundColor: 'rgba(90, 70, 52, 0.7)',
                    borderColor: 'rgba(90, 70, 52, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) { return '₱' + value; }
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });

    
        const noFeedbackMessage = document.getElementById('no-feedback');
    
        const feedbackItems = document.querySelectorAll('#customer-feedback .feedback-item');
        if (feedbackItems.length === 0) {
            
            noFeedbackMessage.style.display = 'block';
        }

        
        const editFab = document.getElementById("editFab");
        const editModal = document.getElementById("editModal");
        const cancelModalBtn = document.getElementById("cancelModalBtn");
        const saveChangesBtn = document.getElementById("saveChangesBtn");

        
        editFab.onclick = () => {
            document.getElementById("aboutText").value = document.getElementById("footer-about-p").innerText;
            document.getElementById("addressText").value = document.getElementById("footer-address").innerText;
            document.getElementById("phoneText").value = document.getElementById("footer-phone").innerText;
            document.getElementById("emailText").value = document.getElementById("footer-email").innerText;
            document.getElementById("facebookLink").value = document.getElementById("footer-facebook-link").href;
            document.getElementById("instagramLink").value = document.getElementById("footer-instagram-link").href;
            document.getElementById("twitterLink").value = document.getElementById("footer-twitter-link").href;
            editModal.style.display = "flex";
        };

        
        const closeModal = () => {
            editModal.style.display = "none";
        };

        cancelModalBtn.onclick = closeModal;
        window.onclick = (event) => {
            if (event.target == editModal) {
                closeModal();
            }
        };

        
        saveChangesBtn.onclick = async () => {
            const formData = new FormData();
            formData.append('aboutText', document.getElementById("aboutText").value);
            formData.append('addressText', document.getElementById("addressText").value);
            formData.append('phoneText', document.getElementById("phoneText").value);
            formData.append('emailText', document.getElementById("emailText").value);
            formData.append('facebookLink', document.getElementById("facebookLink").value);
            formData.append('instagramLink', document.getElementById("instagramLink").value);
            formData.append('twitterLink', document.getElementById("twitterLink").value);

            try {
                const response = await fetch('save_footer.php', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();
                alert(result.message);

                if (result.success) {
                    
                    document.getElementById("footer-about-p").innerText = formData.get('aboutText');
                    document.getElementById("footer-address").innerText = formData.get('addressText');
                    document.getElementById("footer-phone").innerText = formData.get('phoneText');
                    document.getElementById("footer-email").innerText = formData.get('emailText');

                    function updateLink(id, value, iconClass) {
                        const link = document.getElementById(id);
                        link.href = value;
                        const username = value.split("/").filter(Boolean).pop() || "profile";
                        link.innerHTML = `<i class="${iconClass}"></i> ${username}`;
                    }
                    updateLink("footer-facebook-link", formData.get('facebookLink'), "fab fa-facebook-f");
                    updateLink("footer-instagram-link", formData.get('instagramLink'), "fab fa-instagram");
                    updateLink("footer-twitter-link", formData.get('twitterLink'), "fab fa-twitter");
                    closeModal();
                }
            } catch (error) {
                console.error('Error:', error);
                alert('An error occurred while saving footer content.');
            }
        };

        
        function updateAdminNotifCounter() {
            const lastCount = parseInt(localStorage.getItem('lastAdminNotifCount') || 0);
            const contactMessages = JSON.parse(localStorage.getItem('contactMessages')) || [];
            const orderHistory = JSON.parse(localStorage.getItem('orderHistory')) || [];
            const adminNotifications = JSON.parse(localStorage.getItem('adminNotifications')) || [];
            const currentCount = contactMessages.length + orderHistory.length + adminNotifications.length;
            const newNotifs = currentCount - lastCount;

            const badge = document.getElementById('admin-notif-badge');
            if (badge && newNotifs > 0) {
                badge.textContent = newNotifs > 9 ? '9+' : newNotifs;
                badge.style.display = 'block';
            }
        }
        updateAdminNotifCounter();
    </script>
</body>
</html>
