<?php
session_start();

// --- DATABASE CONNECTION ---
$conn = new mysqli("localhost", "root", "", "cafe_amore_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Redirect if not logged in as admin
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

$message = '';
$message_type = ''; // 'success' or 'error'

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    $admin_username = "Admin";

    if ($new_password !== $confirm_password) {
        $message = "Ang mga bagong password ay hindi magkatugma!";
        $message_type = 'error';
    } else {
        $stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");
        $stmt->bind_param("s", $admin_username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows == 1) {
            $stmt->bind_result($hashed_password);
            $stmt->fetch();

            if (password_verify($current_password, $hashed_password)) {
                $new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $update_stmt = $conn->prepare("UPDATE users SET password = ? WHERE username = ?");
                $update_stmt->bind_param("ss", $new_hashed_password, $admin_username);

                if ($update_stmt->execute()) {
                    $message = "Password Change Successfully!";
                    $message_type = 'success';
                } else {
                    $message = "invalid password.";
                    $message_type = 'error';
                }
                $update_stmt->close();
            } else {
                $message = "Invalid Password!";
                $message_type = 'error';
            }
        } else {
            $message = "Not found.";
            $message_type = 'error';
        }
        $stmt->close();
    }
}

// --- FETCH FOOTER CONTENT ---
$footer_content = [];
$footer_result = $conn->query("SELECT * FROM footer_content WHERE id = 1");
if ($footer_result && $footer_result->num_rows > 0) {
    $footer_content = $footer_result->fetch_assoc();
}

// --- FETCH NOTIFICATION COUNT ---
$notif_count = 0;
$count_result = $conn->query("SELECT COUNT(*) as unread_count FROM notifications WHERE is_read = 0");
if ($count_result) {
    $notif_count = $count_result->fetch_assoc()['unread_count'];
}

$conn->close();
function get_social_username($url) {
    if (empty($url)) return '';
    return basename(parse_url($url, PHP_URL_PATH));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Café Amore | Admin Settings</title>
  <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    #settings-section {
      padding: 100px 20px 60px;
      max-width: 600px;
      margin: 0 auto;
    }
    .settings-container {
      background: #fff;
      padding: 40px;
      border-radius: 10px;
      box-shadow: 0 8px 25px rgba(0,0,0,0.1);
      text-align: center;
    }
    .settings-container h2 {
      font-size: 2.5rem;
      color: var(--accent-dark);
      margin-bottom: 20px;
    }
    .form-message {
        padding: 10px;
        margin-bottom: 15px;
        border-radius: 5px;
        font-weight: bold;
    }
    .form-message.success { background-color: #d4edda; color: #155724; }
    .form-message.error { background-color: #f8d7da; color: #721c24; }
  </style>
</head>
<body>
  <header>
    <nav class="navbar">
      <div class="logo"><span><img src="coffee-logo.png" alt=""></span> Café Amore</div>
      <ul class="nav-links" id="navLinks">
        <li><a href="AdminDashboard.php">Home</a></li>
        <li><a href="AdminAbout.php">About</a></li>
        <li><a href="AdminMenu.php">Menu</a></li>
        <li><a href="AdminContact.php">Contact</a></li>
        <li><a href="AdminNotif.php" title="Activity Log" style="position: relative;">
            <i class="fas fa-bell"></i>
            <?php if ($notif_count > 0): ?><span class="notification-badge"><?php echo $notif_count > 9 ? '9+' : $notif_count; ?></span><?php endif; ?>
        </a></li>
        <li><a href="AdminSetting.php" class="active" title="Settings"><i class="fas fa-cog"></i></a></li>
        <li><a href="login.php" title="Log Out"><i class="fas fa-sign-out-alt"></i></a></li>
      </ul>
      <div class="hamburger" id="hamburger">☰</div>
    </nav>
  </header>

  <main>
    <section id="settings-section">
      <div class="settings-container">
        <h2>Admin Settings</h2>
        <p>Palitan ang iyong password dito.</p>

        <?php if (!empty($message)): ?>
          <p class="form-message <?php echo $message_type; ?>"><?php echo $message; ?></p>
        <?php endif; ?>

        <form id="settingsForm" method="POST" action="AdminSetting.php">
          <div class="input-group">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" value="Admin" readonly>
          </div>
          <div class="input-group">
            <label for="current_password">Kasalukuyang Password</label>
            <input type="password" id="current_password" name="current_password" required>
          </div>
          <div class="input-group">
            <label for="new_password">Bagong Password</label>
            <input type="password" id="new_password" name="new_password" required>
          </div>
          <div class="input-group">
            <label for="confirm_password">Kumpirmahin ang Bagong Password</label>
            <input type="password" id="confirm_password" name="confirm_password" required>
          </div>
          <button type="submit">I-save ang mga Pagbabago</button>
        </form>
      </div>
    </section>
  </main>

  <footer>
    <div class="footer-content">
      <div class="footer-section about"><p><?php echo htmlspecialchars($footer_content['about_text']); ?></p></div>
      <div class="footer-section contact-info"><h3>Contact Us</h3><?php if (!empty($footer_content['address'])): ?><p><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($footer_content['address']); ?></p><?php endif; ?><?php if (!empty($footer_content['phone'])): ?><p><i class="fas fa-phone"></i> <?php echo htmlspecialchars($footer_content['phone']); ?></p><?php endif; ?><?php if (!empty($footer_content['email'])): ?><p><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($footer_content['email']); ?></p><?php endif; ?></div>
      <div class="footer-section social"><h3>Follow Us</h3><?php if (!empty($footer_content['facebook_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['facebook_url']); ?>" target="_blank"><i class="fab fa-facebook-f"></i> <?php echo get_social_username($footer_content['facebook_url']); ?></a></p><?php endif; ?><?php if (!empty($footer_content['instagram_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['instagram_url']); ?>" target="_blank"><i class="fab fa-instagram"></i> <?php echo get_social_username($footer_content['instagram_url']); ?></a></p><?php endif; ?><?php if (!empty($footer_content['twitter_url'])): ?><p><a href="<?php echo htmlspecialchars($footer_content['twitter_url']); ?>" target="_blank"><i class="fab fa-twitter"></i> <?php echo get_social_username($footer_content['twitter_url']); ?></a></p><?php endif; ?></div>
    </div>
    <div class="footer-bottom"><p>© 2025 Café Amore. All rights reserved.</p></div>
  </footer>

  <script>
    const hamburger = document.getElementById("hamburger");
    const navLinks = document.getElementById("navLinks");
    hamburger.addEventListener("click", () => navLinks.classList.toggle("show"));
  </script>
</body>
</html>